I'm dejoy ,come from china.I had provide some suggest for JvInterpreter and you acept item, thanks!
Now,I want to Donate some code write by me.That's Add a TJvColorPanel,like office  xp style,Rewrite the JvColorForm and JvColorButton,Look like office xp style, Support Vcl and Clx,Ther TJvColorButton  compatible with old version,evry beautiful.Add some enhancement,All unit modify at JVCL version 2004-2-6.
.JvJCLUtils.pas
   Add a function "StringStartsWidth" to  correspond with function "StringEndsWith".
.JvComponent.pas    
   Add a IJvPersistentUnPublishedProperty Interface in TJvComponent to Support  Persistent UnPublished Property easily. Please see the demo find details.
   Add a TJvPersistent class.
.JvColorForm.Pas and  JvColorButton.Pas and JvSplitter.Pas
   All Code had ReWrite.need unit JvColorPanel.pas . Ther JvColorButton can float as toolwindow.
.New JvColorPanel.Pas
   Add a TJvColorPanel class.
.New JvInterface.Pas
   Add function Supports  for Delphi5.
   Add TInterfacedPersistent class for Delphi5.   
   
I have some  suggest, Can be add a new unit name JvControls.pas,Move the TJvCustomControl and other Control class from JvComponent.pas to JvControls.pas,only keep the TJvPersistent and JvComponent in JvComponent.pas,OK?