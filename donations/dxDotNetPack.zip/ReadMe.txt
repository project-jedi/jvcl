
{*******************************************************************}
{                                                                   }
{   Design eXperience .Net Component Suite                          }
{                                                                   }
{   Copyright (c) 2002 APRIORI business solutions AG                }
{   (W)ritten by M. Hoffmann - ALL RIGHTS RESERVED.                 }
{                                                                   }
{   DEVELOPER NOTES:                                                }
{   ==========================================================      }
{   This file is part of a component suite called Design            }
{   eXperience and may be used in freeware- or commercial           }
{   applications. The package itself is distributed as              }
{   freeware with full sourcecodes.                                 }
{                                                                   }
{   Feel free to fix bugs or include new features if you are        }
{   familiar with component programming. If so, please email        }
{   me your modifications, so it will be possible for me to         }
{   include nice improvements in further releases:                  }
{                                                                   }
{   Contact: mhoffmann@apriori.de                                   }
{                                                                   }
{*******************************************************************}

Files:
------
ReadMe.txt                          This file
WhatsNew.txt                        Contains Release History

Demo\                               
  dxDemo.dpr                        Demo Project
  MainFrm.dfm                       Demo MainForm
  MainFrm.pas                       Demo MainForm Unit
 
Sources\
  dclDesignExperienceDotNetD6.dpk   Package for Delphi 6
  dxDotNetCtrls.dcr                 Palette Bitmaps
  dxDotNetCtrls.pas                 DotNet Unit

Installation:
-------------
Create a new path under your Delphi installation directory which is
part of the library path ("Tools|Enviroment"):

  Example: D:\Delphi\3rdParty\Design eXperience .Net

Copy all files from the directory "Sources\" to that folder. Start Delphi 
if it's not running yet. Go to "Components|Install Component" and locate 
the necessary package file dependant on which Delphi version you are 
running (dclDesignExperienceDotNetD?). Click "Install" to compile it. You'll 
find the new component(s) under the palette named "Design eXperience .Net".
BTW: If Delphi tolds you that a resource file is missing, just ignore it!

Contact:
--------
If you found a bug or have some improvements please feel free to contact me
under:
  
  mhoffmann@apriori.de
