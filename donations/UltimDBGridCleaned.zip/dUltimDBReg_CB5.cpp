//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("dUltimDBReg_CB5.res");
USEPACKAGE("UltimDB_CB5.bpi");
USEPACKAGE("VCL50.bpi");
USEPACKAGE("VCLDB50.bpi");
USEPACKAGE("RXCTL5.bpi");
USEFORMNS("UltimDBGridProp.pas", Ultimdbgridprop, fmGridProp);
USEUNIT("UltimDBReg.pas");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Source du paquet.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
