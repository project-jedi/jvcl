-----------------------------------------------------------------------------

                              ULTIM DB CONTROLS

                        VCL for Delphi and C++Builder
                       (C) Fr�d�ric Leneuf-Magaud 2001

-----------------------------------------------------------------------------

TESTED WITH:

- C++Builder 5.01 Enterprise with ADO update
- Delphi 5.01 Enterprise with ADO update
- MDAC 2.6 and BDE/SQL 5.11
- RX Library 2.75 with all patches
- QuickReport 3.0.7 Std

-----------------------------------------------------------------------------

KNOWN BUGS AND LIMITATIONS:

[ DBImageEditor ]
- supports only BDE datasets
- some paint programs (only PaintBrush to my knowledge) need WaitBeforeUpdate
  set to True

[ UltimDBGrid ]
- supports only ADO, BDE and RxMemoryData datasets
- the FixedCols value includes invisible columns (hint: move invisible columns
  at the end of the columns list)
- the dgAlwaysShowEditor option is not compatible with custom inplace controls
- EnterAsTab has no effect with some custom inplace controls in editing mode
- if you resize the grid while a custom inplace control is in editing mode,
  the result may not be as expected
- there is no sorting of the TQuery results on a title click (hint: add or
  modify the ORDER BY clause in your SQL statement)
- no memo export with SYLK and text formats
- a TrueType font is recommended for default printing

[ UltimDBFooter ]
- works only with UltimDBGrid
- supports only ADO and BDE datasets
- only one footer bar per grid
- does not update when the grid is refreshed (hint: add UpdateDataPanels(True)
  in your AfterRefresh code)
- does not update with a dynamic dataset cursor when other users modify the
  shared datas (any solution to this problem is really welcome)

-----------------------------------------------------------------------------

LICENSE AND CONDITIONS OF USE:

[ Unregistered user (user WITHOUT license) ]
- you can use UltimDBGrid, UltimDBFooter and DBImageEditor to make freewares
- you must register to use the components in a shareware or commercial
  application
- you must not remove the copyright notice
- you cannot redistribute or sell the original source code
- if you modify the source code, you must indicate your changes and rename
  the component (the name must not include 'Ultim')
- you can distribute your modified source code or compiled modified component
  if it is free
- if you want to sell your modified source code or your compiled modified
  component, you have to ask for my authorization
- if you want to include parts of the original source code into another source
  code, you have to ask for my authorization
- I do not provide any support

[ Registered user (user WITH license) ]
- you can use UltimDBGrid, UltimDBFooter and DBImageEditor to make freewares,
  sharewares and commercial applications
- you must not remove the copyright notice
- you cannot redistribute or sell the original source code
- if you modify the source code, you must indicate your changes and rename
  the component (the name must not include 'Ultim')
- you can distribute your modified source code if it is free
- if you want to sell your modified source code, you have to ask for my
  authorization
- you can sell your compiled modified component without my authorization
- if you want to include parts of the original source code into another source
  code, you have to ask for my authorization
- I provide you with full support
- you will be informed of new versions and bug fixes

[ How to become a registered user? ]
- make me rich and famous :-)
- improve greatly the source code
- fix a major bug
- describe me your project or give me a copy of your commercial application
  and wait for my decision
- be the first one to add your translation in Lang_Str.inc
- pay 12 Euros on my website (see URL below, you can pay in many currencies,
  12 Euros = 79 FF = $12)

-----------------------------------------------------------------------------

TO CONTACT THE AUTHOR:

- Email: logiciels@chello.fr (warn me before sending files)
  I'm a very busy man so I probably won't answer to unregistered users.
- Website: http://perso.chello.fr/users/l/logiciels/ultimvcl/

-----------------------------------------------------------------------------
