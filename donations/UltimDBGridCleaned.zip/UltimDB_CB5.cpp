//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("UltimDB_CB5.res");
USEPACKAGE("VCL50.bpi");
USEPACKAGE("VCLDB50.bpi");
USEPACKAGE("RXCTL5.bpi");
USEPACKAGE("RXDB5.bpi");
USEPACKAGE("VCLADO50.bpi");
USEPACKAGE("VCLBDE50.bpi");
USEPACKAGE("QRPT50.bpi");
USEPACKAGE("VCLJPG50.bpi");
USEUNIT("UltimDBFooter\UltimDBFooter.pas");
USEFORMNS("UltimDBConfig.pas", UltimDBConfig, FUltimDBConfig);
USEFORMNS("UltimDBExport.pas", UltimDBExport, FUltimDBExport);
USEFORMNS("UltimDBFilter.pas", UltimDBFilter, FUltimDBFilter);
USEUNIT("UltimDBReport.pas");
USEFORMNS("UltimDBSelect.pas", UltimDBSelect, FUltimDBSelect);
USEFORMNS("UltimDBSort.pas", UltimDBSort, FUltimDBSort);
USEUNIT("UltimDBGrid.pas");
USEFORMNS("DBImageEditor\DBImageEditor.pas", DBImageEditor, DBImageEditor); /* TFrame: File Type */
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Source du paquet.
//---------------------------------------------------------------------------

#pragma argsused
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
    return 1;
}
//---------------------------------------------------------------------------
