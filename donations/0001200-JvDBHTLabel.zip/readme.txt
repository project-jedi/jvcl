==============================================================================
                           JvHtControls update
                 A Contribute to JVCL Open Source Project
==============================================================================
 
                   Author(s): Maciej Kaczkowski (maciejkaczkowski@wp.pl)
 
                    Based on: JvHtControls.pas
 
  Applicable to JVCL version: 3.0

                 Description: Alternative DB label component with HTML
                              formating

       Source files modified: -
 
          Source files added: JvDBHTLabel.pas

     Tools required to apply: Delphi 5.0

        Tools used to create: Delphi 5.0

     Known incompatibilities: -

                  Known bugs: [X] not tested on BCB & Kylix

                       To do: -

                       Other: -
Create label and assign DataSource. As Mask use format:
First name: <b><FIELD="FIRSTNAME"></b><br>Second name: <b><FIELD="NAME"></b>

FIRSTNAME and NAME are names of fields from DataSource

==============================================================================
  [!] Major news
  [+] New feature
  [-] A bug fixed
  [*] A bug fixed and/or functionality improved
  [X] Incompatibilities