name: Christian Vogt
email: christian@fam-vogt.de
website (under construction) www.fam-vogt.de
anoymous: NO

The code is documented with DOC-O-MATIC, a .CHM and HTML are available in directory "help".