#include "JvMouseGesture_map.h"
#include "JvMouseGesture_html_map.h"

int HTML_ID_Mapping(int id)
{
  switch(id)
  {
    case IDH_JVCL_INC                                          : return IDH_HTML_JVCL_INC;
    case IDH_JvCurrentHook                                     : return IDH_HTML_JvCurrentHook;
    case IDH_JVMG_DOWN                                         : return IDH_HTML_JVMG_DOWN;
    case IDH_JVMG_LEFT                                         : return IDH_HTML_JVMG_LEFT;
    case IDH_JVMG_LEFTLOWER                                    : return IDH_HTML_JVMG_LEFTLOWER;
    case IDH_JVMG_LEFTUPPER                                    : return IDH_HTML_JVMG_LEFTUPPER;
    case IDH_JVMG_RIGHT                                        : return IDH_HTML_JVMG_RIGHT;
    case IDH_JVMG_RIGHTLOWER                                   : return IDH_HTML_JVMG_RIGHTLOWER;
    case IDH_JVMG_RIGHTUPPER                                   : return IDH_HTML_JVMG_RIGHTUPPER;
    case IDH_JVMG_UP                                           : return IDH_HTML_JVMG_UP;
    case IDH_JvMouseGesture_pas                                : return IDH_HTML_JvMouseGesture_pas;
    case IDH_JvMouseGestureHook_integer_word_longword          : return IDH_HTML_JvMouseGestureHook_integer_word_longword;
    case IDH_JvMouseGestureHookAlreadyInstalled                : return IDH_HTML_JvMouseGestureHookAlreadyInstalled;
    case IDH_JvMouseGestureInterpreter                         : return IDH_HTML_JvMouseGestureInterpreter;
    case IDH_TJvActivationMode                                 : return IDH_HTML_TJvActivationMode;
    case IDH_TJvMouseGesture                                   : return IDH_HTML_TJvMouseGesture;
    case IDH_TJvMouseGesture_Active                            : return IDH_HTML_TJvMouseGesture_Active;
    case IDH_TJvMouseGesture_Create_TComponent                 : return IDH_HTML_TJvMouseGesture_Create_TComponent;
    case IDH_TJvMouseGesture_Delay                             : return IDH_HTML_TJvMouseGesture_Delay;
    case IDH_TJvMouseGesture_Destroy                           : return IDH_HTML_TJvMouseGesture_Destroy;
    case IDH_TJvMouseGesture_EndMouseGesture                   : return IDH_HTML_TJvMouseGesture_EndMouseGesture;
    case IDH_TJvMouseGesture_Gesture                           : return IDH_HTML_TJvMouseGesture_Gesture;
    case IDH_TJvMouseGesture_Grid                              : return IDH_HTML_TJvMouseGesture_Grid;
    case IDH_TJvMouseGesture_OnJvMouseGestureCustomInterpretation: return IDH_HTML_TJvMouseGesture_OnJvMouseGestureCustomInterpretation;
    case IDH_TJvMouseGesture_OnJvMouseGestureDown              : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureDown;
    case IDH_TJvMouseGesture_OnJvMouseGestureLeft              : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureLeft;
    case IDH_TJvMouseGesture_OnJvMouseGestureLeftLowerEdge     : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureLeftLowerEdge;
    case IDH_TJvMouseGesture_OnJvMouseGestureLeftUpperEdge     : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureLeftUpperEdge;
    case IDH_TJvMouseGesture_OnJvMouseGestureRight             : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureRight;
    case IDH_TJvMouseGesture_OnJvMouseGestureRightLowerEdge    : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureRightLowerEdge;
    case IDH_TJvMouseGesture_OnJvMouseGestureRightUpperEdge    : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureRightUpperEdge;
    case IDH_TJvMouseGesture_OnJvMouseGestureUp                : return IDH_HTML_TJvMouseGesture_OnJvMouseGestureUp;
    case IDH_TJvMouseGesture_StartMouseGesture_Integer_Integer : return IDH_HTML_TJvMouseGesture_StartMouseGesture_Integer_Integer;
    case IDH_TJvMouseGesture_TrailActive                       : return IDH_HTML_TJvMouseGesture_TrailActive;
    case IDH_TJvMouseGesture_TrailInterval                     : return IDH_HTML_TJvMouseGesture_TrailInterval;
    case IDH_TJvMouseGesture_TrailLength                       : return IDH_HTML_TJvMouseGesture_TrailLength;
    case IDH_TJvMouseGesture_TrailLimit                        : return IDH_HTML_TJvMouseGesture_TrailLimit;
    case IDH_TJvMouseGesture_TrailMouseGesture_Integer_Integer : return IDH_HTML_TJvMouseGesture_TrailMouseGesture_Integer_Integer;
    case IDH_TJvMouseGestureButton                             : return IDH_HTML_TJvMouseGestureButton;
    case IDH_TJvMouseGestureHook                               : return IDH_HTML_TJvMouseGestureHook;
    case IDH_TJvMouseGestureHook_ActivationMode                : return IDH_HTML_TJvMouseGestureHook_ActivationMode;
    case IDH_TJvMouseGestureHook_Active                        : return IDH_HTML_TJvMouseGestureHook_Active;
    case IDH_TJvMouseGestureHook_Create_TComponent             : return IDH_HTML_TJvMouseGestureHook_Create_TComponent;
    case IDH_TJvMouseGestureHook_CreateForThreadOrSystem_TComponent_Cardinal: return IDH_HTML_TJvMouseGestureHook_CreateForThreadOrSystem_TComponent_Cardinal;
    case IDH_TJvMouseGestureHook_CurrentHook                   : return IDH_HTML_TJvMouseGestureHook_CurrentHook;
    case IDH_TJvMouseGestureHook_Destroy                       : return IDH_HTML_TJvMouseGestureHook_Destroy;
    case IDH_TJvMouseGestureHook_HookInstalled                 : return IDH_HTML_TJvMouseGestureHook_HookInstalled;
    case IDH_TJvMouseGestureHook_MouseButton                   : return IDH_HTML_TJvMouseGestureHook_MouseButton;
    case IDH_TJvMouseGestureHook_OnJvMouseGestureCustomInterpretation: return IDH_HTML_TJvMouseGestureHook_OnJvMouseGestureCustomInterpretation;
    case IDH_TOnJvMouseGestureCustomInterpretation             : return IDH_HTML_TOnJvMouseGestureCustomInterpretation;
    case IDH_TOnJvMouseGestureSimple                           : return IDH_HTML_TOnJvMouseGestureSimple;
    default: return -1;
  }
}
