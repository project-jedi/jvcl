TAlContainer

VCL Component to create Desktop Shortcuts
Author: Alejandro Castro
alejandro@alfra.info
www.alfra.info
Date: 26/Jun/2003


The purpose of the component is create shortcuts (like the shorcuts of Windows Desktop) inside
the Main Form of an App that link to the several menu items of a Main Menu of the App.

We can create, move, delete, change caption, change picture of the differents shortcuts.

We can save the shortcuts to a file name.

Tha name of the component is TAlContainer, the component has the control of the differents shortcuts
(TAlShortCut) via a TCollection object (TAlShortCutCollection) and the items are controlled via
TCollectionItem (TAlShortCutItem)

Properties:
===========
Directory: The directory where the shortcuts will be saved, the options are the Windows Directory,
           My Documents or Application Data.

FileName:  The filename where the shortcuts will be saved, the default is the name of the App.
ImageList: The ImageList object containing the differents images.
PopUpMenu: The popupmenu that can give the options to rename, delete, change picture.
Menu:      The MainMenu of the app.

Methods:
========
LoadFromFile: Boolean
Read the FileName containing the ShortCuts.

SaveToFile
Save the Shortcuts to the FileName.

Add
Add a shortcut.

Delete
Delete the focused shortcut.

Rename (Caption: String)
Rename the focused shortcut with the Caption

ChangePicture: Boolean
Change the picture and select from the ImageList

Shortcuts[i]: To give access to the list of shortcuts.


Usage:
On the main form of the app we need several components:

1. The Container (AlContainer1)
1. A Main Menu (MainMenu1)
2. An Image List (ImageList1)
3. A PopUpMenu to create shortcuts (PopUpMenu1)
4. A PopUpMenu to control the differents operations over the individuals shortcuts like: move, delete,
   change picture and change image. (PopUpMenu2)

a) The PopUpMenu1 need an Item "ADD", this Item has the next code to create ShortCuts:
   AlContainer1.Add;
   
b) The PopUpMenu2 need at least 3 Items
 DELETE:
 The code could be:
 AlContainer1.Delete;

 CHANGE PICTURE
 The code could be:
 AlContainer1.ChangePicture;

 RENAME
 The code could be:
 var
   xString: String;
 begin
   xString:=InputBox('Change Caption','Enter New caption','');
   if xString<>'' then
     AlContainer1.Rename(xString);
 end;


On the onShow event of the Main Form we need the next code:
  AlContainer1.LoadFromFile;
  
On the OnDestroy event of the Main Form we need the next code:
  AlContainer1.SaveToFile;

To create shortcuts manually:
    with AlContainer1.ShortCuts.Add do begin // set the properties of the shortcut
      AlShortCut.Left:=80;
      AlShortCut.Top:=80;
      AlShortCut.Caption:='Screen 1';
      AlShortCut.ImageIndex:=3;
      AlShortCut.MenuItemName:='Screen11';
    end;

--------------------------------------------------------
The class TAlShortCut contain the differents ShortCuts.

Properties
==========

ImageIndex: The Index on the Image index containing the picture
Picture : Contains the picture.
Caption: Contains the caption of the shortcut.
Enabled:
Visible:
PopupMenu:
Width default 70: The width of the shortcut.
Left default 0: The left position of the shortcut.
Top default 0: The top position of the shortcut.
Space default 2: The space between the picture and the caption.
Command: The command number of the Menu Item.
EnableDrag: Allow or disallow the drag and drop operation with the shortcut.
MenuItemName : The menu item corresponding to the main menu.


