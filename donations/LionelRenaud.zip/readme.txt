Correction sur JvProgressComponent.pas :
- Ajout de la propri�t� StayOnTop � la form
- Hauteur du label de 16 (et non 13 car sinon le label est coup�)

Correction sur JvMarkupLabel.pas :
- Rajout de propri�t�s (Alignement, Font, ...)

Nouvelles unit�s :
- JvExportDBGrid.pas : permet d'exporter une grille vers Word, Excel, HTML, CSV. Il me manque encore XML � faire.
C'est un composant non visuel qu'il suffit de placer sur la fiche et de relier � la grille.
On appelle la m�thode ExportGrid pour faire l'export ...

- JvMyDBGridSelectColumn.pas (*.dfm) : forme utilis�e par JJvMyDBGrid.pas pour afficher/masquer les colonnes d'une grille.
Permet de s�lectionner les colonnes parmis celle d�j� existantes dans la grille ou directement sur le dataset.
Dans le cas ou la grille est vide et ou on choisit les colonnes directement dans le dataset, il y a parfois
des probl�mes : je n'ai pas encore trouv� la cause ...

- JvMyDBGrid.pas : C'est la TJvDBGrid que j'ai pour le moment extrait de l'unit� JvDBControls.pas et renommer pour
qu'il n'y ai pas de confusion. Si cette classe est accept�e, on pourra soit la r�int�grer dans l'unit� JvDBControls,
soit la garder dans une unit� ind�pendante JvDBGrid. Je pense que ce serait le mieux pour �viter d'avoir des
unit�s trop volumineuses.
Les modifications dans cette classe sont (A chaque fois, j'ai mis un commentaire dans le texte) :
- Nouvelles propri�t�s : 
	AlternRowColor : Alterne les couleurs de fond des lignes
	PostOnEnter : Post lors de l'appuie de "entr�e"
	SelectColumn : choix de l'affichage des colonnes (grille ou dataset)
	SortedField : Nom de la colonne tri�
	ShowTitleHint : Affiche un Hint sur le titre des colonnes
	TitleArrow : Dessine un triangle sur la cellule (0,0) et active l'affichage de la s�lection
des colonnes lors d'un click gauche dessus. Active aussi le popup du TitlePopup si d�fini et si
click droit dessus
	TitlePopup : Menu popup associ� � TitleArrow 
	OnTitleHintEvent : Ev�nement qui permet d'afficher un hint particulier sur un titre de colonne
	OnTitleArrowMenuEvent : Ev�nement se produisant lors d'un click sur TitleArrow 

- Gestion automatique du tri des colonnes. Si l'on g�n�re des Index sur les champs en les nommant
"IXnom du champ", la grille tri automatiquement lors d'un click sur le titre d'une colonne

- Modification du InplaceEdit pour utilisation de TJvDBLookupList. Le but �tait aussi de pouvoir
mieux g�rer la roulette de la souris. Mais jusqu'� pr�sent, je n'ai pas r�ussi � avoir le bon
comportement : En effet, lorsque l'on a une colonne li� � un champ lookup, on a une liste 
d�roulante qui appara�t lors du click sur la cellule. Et lorsqu'elle est d�roul�, si on a le 
malheur de faire tourner la roulette, celle-ci dispara�t et l'application se bloque un moment.
Comment faire pour ne pas perdre le focus de la liste et la faire d�filer ??????
En fait une piste : Le InplaceEdit anc�tre redirige l'�v�nement sur la grille dans le DoMouseWheel. 
Il faudrait modifier cela, mais je vois pas comment ....


A noter le fichier de ressource qui va avec.


Ci-joint une d�mo. Pour la faire tourner, il suffit d'installer les composants ci-dessus (l'unit� DBPersoReg.pas 
devrait faire l'affaire).
La grille est aliment�e par un ClientDataSet via un provider sur une Table. Cela me permet de faire ce que
je veux avec les index.

---------------------------------------------------------------
Corrections to JvProgressComponent:
- Form is made StayOnTop
- Height of label set to 16 (13 cuts part of the text)

Corrections to JvMarkupLabel:
- Added properties (Alignment, Font...)

New units/components
- JvExportDBGrid: drop it on a form and its ExportGrid method will 
export a DBGrid to many formats (MSWord, MSExcel, HTML, CSV and XML is coming).
- JvMyDBGridSelectColumn (form): Form used by JvMyDBGrid to select 
columns to show or hide from those that are in the grid. If the grid is 
empty or you choose columns directly in the dataset, it doesn't work 
correctly. Still have to find out why.
- JvMyDBGrid: It's the JvDBGrid extracted and renamed to avoid name 
conflicts. I think it'd be best to split the JvDBControls unit to keep 
the size of units small. Here are the changes (comments in the source 
code too):
New properties:
   - AlternRowColor: Alterns background colors every 2 row
   - PostOnEnter: Posts the contents when "Enter" is pressed
   - SelectColumn: Choose the display of columns (grid or dataset)
   - SortedField: Name of the sorted field
   - TitleArrow: Draws a triangle on 0,0. If left click, turns on column 
selection. If right click shows the popup menu indicated by TitlePopup
   - TitlePopup: Popup menu associated with TitleArrow
   - OnTitleHintEvent: Event to allow showing a hint on a column title
   - OnTitleArrowMenuEvent: Event triggerred when clicking on TitleArrow

Automatic handling of column sorting. If one generates Index on fields 
by naming them IXfieldname, the grid sort automatically when clicking on 
the title of a column

Modification of the InplaceEdit to try to allow the mousewheel to work 
when a column is linked to a lookup field. But this still needs some fixing.

The resource file comes in the zip file, along with a demo. The registration 
file should be enough to install the components.
The grid is fed by a ClientDataSet via a provider on a Table. 
This allows me to do what I want with the Index
---------------------------------------------------------------
