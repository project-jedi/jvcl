//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "BasicMain.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "JvHidControllerClass"
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::HidCtlDeviceChange(TObject *Sender)
{
  DeviceList->Clear();
  HidCtl->Enumerate();
}
//---------------------------------------------------------------------------

bool __fastcall TMainForm::HidCtlEnumerate(TJvHidDevice *HidDev,
      const int Idx)
{
  AnsiString s;

  DeviceList->Items->Add(s.sprintf("%.4x/%.4x", HidDev->Attributes.VendorID,
      HidDev->Attributes.ProductID));
  return(true);
}
//---------------------------------------------------------------------------

