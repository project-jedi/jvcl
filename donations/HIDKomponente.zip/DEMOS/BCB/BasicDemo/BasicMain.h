//---------------------------------------------------------------------------

#ifndef BasicMainH
#define BasicMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "JvHidControllerClass.hpp"
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Description;
        TListBox *DeviceList;
        TJvHidDeviceController *HidCtl;
        void __fastcall HidCtlDeviceChange(TObject *Sender);
        bool __fastcall HidCtlEnumerate(TJvHidDevice *HidDev,
          const int Idx);
private:	// User declarations
public:		// User declarations
        __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
