//---------------------------------------------------------------------------

#ifndef InfoH
#define InfoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include "JvHidControllerClass.hpp"
#include "UsagesInfo.h"
#include "Hid.hpp"
//---------------------------------------------------------------------------
class TInfoForm : public TForm
{
__published:	// IDE-managed Components
        TMemo *InfoMemo;
        TButton *Save;
        TSaveDialog *SaveDialog;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall SaveClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        TJvHidDevice *Dev;
        __fastcall TInfoForm(TComponent* Owner);
        void __fastcall CollectBtnInfo(WORD Val, char *Title, char *TitleBar);
        void __fastcall CollectValueInfo(WORD Val, char *Title, char *TitleBar);
};
//---------------------------------------------------------------------------
extern PACKAGE TInfoForm *InfoForm;
//---------------------------------------------------------------------------
#endif
