//---------------------------------------------------------------------------

#ifndef UsagesMainH
#define UsagesMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "JvHidControllerClass.hpp"
#include <Buttons.hpp>
#include "Info.h"
//---------------------------------------------------------------------------
class TUsagesForm : public TForm
{
__published:	// IDE-managed Components
        TListBox *DevListBox;
        TJvHidDeviceController *HidCtl;
        TSpeedButton *Info;
        TLabel *Description;
        void __fastcall HidCtlDeviceChange(TObject *Sender);
        bool __fastcall HidCtlEnumerate(TJvHidDevice *HidDev,
          const int Idx);
        void __fastcall InfoClick(TObject *Sender);
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TUsagesForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TUsagesForm *UsagesForm;
//---------------------------------------------------------------------------
#endif
