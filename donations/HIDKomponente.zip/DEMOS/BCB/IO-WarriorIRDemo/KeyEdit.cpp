//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "KeyEdit.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TKeyEditForm *KeyEditForm;
//---------------------------------------------------------------------------
__fastcall TKeyEditForm::TKeyEditForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
