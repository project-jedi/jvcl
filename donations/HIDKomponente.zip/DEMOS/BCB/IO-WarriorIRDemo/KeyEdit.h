//---------------------------------------------------------------------------

#ifndef KeyEditH
#define KeyEditH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TKeyEditForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Address;
        TLabel *Value;
        TEdit *Name;
        TEdit *Keys;
        TButton *OK;
        TButton *Cancel;
private:	// User declarations
public:		// User declarations
        __fastcall TKeyEditForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TKeyEditForm *KeyEditForm;
//---------------------------------------------------------------------------
#endif
