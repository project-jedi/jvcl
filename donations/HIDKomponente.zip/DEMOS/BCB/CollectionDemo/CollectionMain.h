//---------------------------------------------------------------------------

#ifndef CollectionMainH
#define CollectionMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "JvHidControllerClass.hpp"
#include <ComCtrls.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TCollectionDemoForm : public TForm
{
__published:	// IDE-managed Components
        TLabel *Description;
        TSaveDialog *SaveDialog;
        TTreeView *DeviceTree;
        TButton *Save;
        TJvHidDeviceController *HidCtl;
        void __fastcall FormShow(TObject *Sender);
        void __fastcall HidCtlDeviceChange(TObject *Sender);
        bool __fastcall HidCtlEnumerate(TJvHidDevice *HidDev,
          const int Idx);
        void __fastcall SaveClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        TTreeNode *Root;
        __fastcall TCollectionDemoForm(TComponent* Owner);
        void __fastcall EnumerateNodes(TJvHidDevice *HidDev,
          TTreeNode *Parent, Word Idx, Word NumSiblings);
        void __fastcall EnumerateCaps(TJvHidDevice *HidDev,
          TTreeNode *Parent, Word Idx);
        void __fastcall EnumerateButtonCaps(TJvHidDevice *HidDev,
          TTreeNode *Parent, WORD Idx, THIDPReportType ReportType,
          char *ReportText);
        void __fastcall EnumerateValueCaps(TJvHidDevice *HidDev,
          TTreeNode *Parent, WORD Idx, THIDPReportType ReportType,
          char *ReportText);
};
//---------------------------------------------------------------------------
extern PACKAGE TCollectionDemoForm *CollectionDemoForm;
//---------------------------------------------------------------------------
#endif
