#include "Hid.hpp"
#include "HidUsage.hpp"

void UsageAndUsagePageText(TUsage UsagePage, TUsage Usage,
 AnsiString *UsagePageText, AnsiString *UsageText);
