//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Info.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TInfoForm *InfoForm;
//---------------------------------------------------------------------------
__fastcall TInfoForm::TInfoForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TInfoForm::FormShow(TObject *Sender)
{
  int I;
  AnsiString S;

  VendorName->Caption  = Dev->VendorName;
  ProductName->Caption = Dev->ProductName;
  SerialNo->Caption = Dev->SerialNumber;
  Vid->Caption  = IntToHex(Dev->Attributes.VendorID, 4);
  Pid->Caption  = IntToHex(Dev->Attributes.ProductID, 4);
  Vers->Caption = IntToHex(Dev->Attributes.VersionNumber, 4);
  if(Dev->Caps.InputReportByteLength > 0)
    InputLen->Caption   = IntToHex(Dev->Caps.InputReportByteLength-1, 1);
  if(Dev->Caps.OutputReportByteLength > 0)
    OutputLen->Caption  = IntToHex(Dev->Caps.OutputReportByteLength-1, 1);
  if(Dev->Caps.FeatureReportByteLength > 0)
    FeatureLen->Caption = IntToHex(Dev->Caps.FeatureReportByteLength-1, 1);
  for(I = 1; I < 256; I++)
    if(Dev->DeviceStrings[I] != "")
      DevStrings->Items->Add(S.sprintf("%3d) %s", I, Dev->DeviceStrings[I]));
  for(I = 0; I < Dev->LanguageStrings->Count; I++)
    LangStrings->Items->Add(Dev->LanguageStrings->Strings[I]);
}
//---------------------------------------------------------------------------
