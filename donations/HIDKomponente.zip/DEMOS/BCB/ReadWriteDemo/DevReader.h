//---------------------------------------------------------------------------

#ifndef DevReaderH
#define DevReaderH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "JvHidControllerClass.hpp"
#include <Buttons.hpp>
#include <Dialogs.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
        TListBox *DevListBox;
        TListBox *HistoryListBox;
        TSpeedButton *ReadBtn;
        TSpeedButton *WriteBtn;
        TSpeedButton *SaveBtn;
        TSaveDialog *SaveDialog;
        TEdit *ReportID;
        TEdit *Edit1;
        TLabel *Label1;
        TJvHidDeviceController *HidCtl;
        TSpeedButton *InfoBtn;
        void __fastcall HidCtlDeviceChange(TObject *Sender);
        bool __fastcall HidCtlEnumerate(TJvHidDevice *HidDev,
          const int Idx);
        void __fastcall ReadBtnClick(TObject *Sender);
        void __fastcall DevListBoxClick(TObject *Sender);
        void __fastcall SaveBtnClick(TObject *Sender);
        void __fastcall FormActivate(TObject *Sender);
        void __fastcall WriteBtnClick(TObject *Sender);
        void __fastcall InfoBtnClick(TObject *Sender);
        void __fastcall HidCtlDeviceDataError(TJvHidDevice *HidDev,
          DWORD Error);
private:	// User declarations
public:		// User declarations
        TEdit *Edits[64];
        TJvHidDevice *CurrentDevice;
        __fastcall TMainForm(TComponent* Owner);
        void __fastcall ShowRead(TJvHidDevice *HidDev,
              BYTE ReportID, const void *Data, WORD Size);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
