//---------------------------------------------------------------------------

#ifndef InfoH
#define InfoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "JvHidControllerClass.hpp"
//---------------------------------------------------------------------------
class TInfoForm : public TForm
{
__published:	// IDE-managed Components
        TListBox *DevStrings;
        TLabel *Label1;
        TLabel *Label2;
        TLabel *Label3;
        TLabel *Label4;
        TLabel *Vid;
        TLabel *Pid;
        TLabel *Vers;
        TLabel *Label5;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TLabel *InputLen;
        TLabel *OutputLen;
        TLabel *FeatureLen;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *VendorName;
        TLabel *ProductName;
        TLabel *Label11;
        TLabel *SerialNo;
        TListBox *LangStrings;
        TLabel *Label12;
        void __fastcall FormShow(TObject *Sender);
private:	// User declarations
public:		// User declarations
        TJvHidDevice *Dev;
        __fastcall TInfoForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TInfoForm *InfoForm;
//---------------------------------------------------------------------------
#endif
