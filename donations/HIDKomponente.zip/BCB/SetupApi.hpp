// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SetupApi.pas' rev: 6.00

#ifndef SetupApiHPP
#define SetupApiHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <CommCtrl.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------
#include "setupapi.h"
#undef SetupGetInfInformation
#undef SetupQueryInfFileInformation
#undef SetupQueryInfOriginalFileInformation
#undef SetupQueryInfVersionInformation
#undef SetupGetInfFileList
#undef SetupOpenInfFile
#undef SetupOpenAppendInfFile
#undef SetupFindFirstLine
#undef SetupFindNextMatchLine
#undef SetupGetLineByIndex
#undef SetupGetLineCount
#undef SetupGetLineText
#undef SetupGetStringField
#undef SetupGetMultiSzField
#undef SetupGetFileCompressionInfo
#undef SetupDecompressOrCopyFile
#undef SetupGetSourceFileLocation
#undef SetupGetSourceFileSize
#undef SetupGetTargetPath
#undef SetupSetSourceList
#undef SetupAddToSourceList
#undef SetupRemoveFromSourceList
#undef SetupQuerySourceList
#undef SetupFreeSourceList
#undef SetupPromptForDisk
#undef SetupCopyError
#undef SetupRenameError
#undef SetupDeleteError
#undef SetupBackupError
#undef SetupSetDirectoryId
#undef SetupSetDirectoryIdEx
#undef SetupGetSourceInfo
#undef SetupInstallFile
#undef SetupInstallFileEx
#undef SetupSetFileQueueAlternatePlatform
#undef SetupSetPlatformPathOverride
#undef SetupQueueCopy
#undef SetupQueueCopyIndirect
#undef SetupQueueDefaultCopy
#undef SetupQueueCopySection
#undef SetupQueueDelete
#undef SetupQueueDeleteSection
#undef SetupQueueRename
#undef SetupQueueRenameSection
#undef SetupCommitFileQueue
#undef SetupScanFileQueue
#undef SetupCopyOEMInf
#undef SetupCreateDiskSpaceList
#undef SetupDuplicateDiskSpaceList
#undef SetupQueryDrivesInDiskSpaceList
#undef SetupQuerySpaceRequiredOnDrive
#undef SetupAdjustDiskSpaceList
#undef SetupAddToDiskSpaceList
#undef SetupAddSectionToDiskSpaceList
#undef SetupAddInstallSectionToDiskSpaceList
#undef SetupRemoveFromDiskSpaceList
#undef SetupRemoveSectionFromDiskSpaceList
#undef SetupRemoveInstallSectionFromDiskSpaceList
#undef SetupIterateCabinet
#undef SetupDefaultQueueCallback
#undef SetupInstallFromInfSection
#undef SetupInstallFilesFromInfSection
#undef SetupInstallServicesFromInfSection
#undef SetupInstallServicesFromInfSectionEx
#undef SetupInitializeFileLog
#undef SetupLogFile
#undef SetupRemoveFileLogEntry
#undef SetupQueryFileLog
#undef SetupLogError
#undef SetupGetBackupInformation
#undef SetupDiCreateDeviceInfoListEx
#undef SetupDiGetDeviceInfoListDetail
#undef SetupDiCreateDeviceInfo
#undef SetupDiOpenDeviceInfo
#undef SetupDiGetDeviceInstanceId
#undef SetupDiEnumInterfaceDevice
#undef SetupDiCreateDeviceInterface
#undef SetupDiCreateInterfaceDeviceA
#undef SetupDiCreateInterfaceDeviceW
#undef SetupDiCreateInterfaceDevice
#undef SetupDiOpenDeviceInterface
#undef SetupDiOpenInterfaceDeviceA
#undef SetupDiOpenInterfaceDeviceW
#undef SetupDiOpenInterfaceDevice
#undef SetupDiGetInterfaceDeviceAlias
#undef SetupDiDeleteInterfaceDeviceData
#undef SetupDiRemoveInterfaceDevice
#undef SetupDiGetDeviceInterfaceDetail
#undef SetupDiGetInterfaceDeviceDetailA
#undef SetupDiGetInterfaceDeviceDetailW
#undef SetupDiGetInterfaceDeviceDetail
#undef SetupDiInstallInterfaceDevices
#undef SetupDiEnumDriverInfo
#undef SetupDiGetSelectedDriver
#undef SetupDiSetSelectedDriver
#undef SetupDiGetDriverInfoDetail
#undef SetupDiGetClassDevs
#undef SetupDiGetClassDevsEx
#undef SetupDiGetINFClass
#undef SetupDiBuildClassInfoListEx
#undef SetupDiGetClassDescription
#undef SetupDiGetClassDescriptionEx
#undef SetupDiInstallClass
#undef SetupDiInstallClassEx
#undef SetupDiOpenClassRegKeyEx
#undef SetupDiCreateDeviceInterfaceRegKey
#undef SetupDiCreateInterfaceDeviceRegKeyA
#undef SetupDiCreateInterfaceDeviceRegKeyW
#undef SetupDiCreateInterfaceDeviceRegKey
#undef SetupDiOpenInterfaceDeviceRegKey
#undef SetupDiDeleteInterfaceDeviceRegKey
#undef SetupDiCreateDevRegKey
#undef SetupDiGetHwProfileListEx
#undef SetupDiGetDeviceRegistryProperty
#undef SetupDiGetClassRegistryProperty
#undef SetupDiSetDeviceRegistryProperty
#undef SetupDiSetClassRegistryProperty
#undef SetupDiGetDeviceInstallParams
#undef SetupDiGetClassInstallParams
#undef SetupDiSetDeviceInstallParams
#undef SetupDiSetClassInstallParams
#undef SetupDiGetDriverInstallParams
#undef SetupDiSetDriverInstallParams
#undef SetupDiGetClassImageListEx
#undef SetupDiGetClassDevPropertySheets
#undef SetupDiClassNameFromGuid
#undef SetupDiClassNameFromGuidEx
#undef SetupDiClassGuidsFromName
#undef SetupDiClassGuidsFromNameEx
#undef SetupDiGetHwProfileFriendlyName
#undef SetupDiGetHwProfileFriendlyNameEx
#undef SetupDiGetActualSectionToInstall

namespace Setupapi
{
//-- type declarations -------------------------------------------------------
typedef wchar_t * *PPWSTR;

typedef char * *PPASTR;

typedef char * *PPSTR;

typedef HICON *PHICON;

typedef INFCONTEXT *PInfContext;

typedef INFCONTEXT  TInfContext;

typedef SP_INF_INFORMATION *PSPInfInformation;

typedef SP_INF_INFORMATION  TSPInfInformation;

typedef SP_ALTPLATFORM_INFO *PSPAltPlatformInfo;

typedef SP_ALTPLATFORM_INFO  TSPAltPlatformInfo;

typedef SP_ORIGINAL_FILE_INFO_A *PSPOriginalFileInfoA;

typedef SP_ORIGINAL_FILE_INFO_W *PSPOriginalFileInfoW;

typedef SP_ORIGINAL_FILE_INFO_A *PSPOriginalFileInfo;

typedef SP_ORIGINAL_FILE_INFO_A  TSPOriginalFileInfoA;

typedef SP_ORIGINAL_FILE_INFO_W  TSPOriginalFileInfoW;

typedef SP_ORIGINAL_FILE_INFO_A  TSPOriginalFileInfo;

typedef unsigned __stdcall (*TSPFileCallbackA)(void * Context, unsigned Notification, unsigned Param1, unsigned Param2);

typedef unsigned __stdcall (*TSPFileCallbackW)(void * Context, unsigned Notification, unsigned Param1, unsigned Param2);

typedef unsigned __stdcall (*TSPFileCallback)(void * Context, unsigned Notification, unsigned Param1, unsigned Param2);

typedef FILEPATHS_A *PFilePathsA;

typedef FILEPATHS_W *PFilePathsW;

typedef FILEPATHS_A *PFilePaths;

typedef FILEPATHS_A  TFilePathsA;

typedef FILEPATHS_W  TFilePathsW;

typedef FILEPATHS_A  TFilePaths;

typedef SOURCE_MEDIA_A *PSourceMediaA;

typedef SOURCE_MEDIA_W *PSourceMediaW;

typedef SOURCE_MEDIA_A *PSourceMedia;

typedef SOURCE_MEDIA_A  TSourceMediaA;

typedef SOURCE_MEDIA_W  TSourceMediaW;

typedef SOURCE_MEDIA_A  TSourceMedia;

typedef CABINET_INFO_A *PCabinetInfoA;

typedef CABINET_INFO_W *PCabinetInfoW;

typedef CABINET_INFO_A *PCabinetInfo;

typedef CABINET_INFO_A  TCabinetInfoA;

typedef CABINET_INFO_W  TCabinetInfoW;

typedef CABINET_INFO_A  TCabinetInfo;

typedef FILE_IN_CABINET_INFO_A *PFileInCabinetInfoA;

typedef FILE_IN_CABINET_INFO_W *PFileInCabinetInfoW;

typedef FILE_IN_CABINET_INFO_A *PFileInCabinetInfo;

typedef FILE_IN_CABINET_INFO_A  TFileInCabinetInfoA;

typedef FILE_IN_CABINET_INFO_W  TFileInCabinetInfoW;

typedef FILE_IN_CABINET_INFO_A  TFileInCabinetInfo;

typedef SP_FILE_COPY_PARAMS_A *PSPFileCopyParamsA;

typedef SP_FILE_COPY_PARAMS_W *PSPFileCopyParamsW;

typedef SP_FILE_COPY_PARAMS_A *PSPFileCopyParams;

typedef SP_FILE_COPY_PARAMS_A  TSPFileCopyParamsA;

typedef SP_FILE_COPY_PARAMS_W  TSPFileCopyParamsW;

typedef SP_FILE_COPY_PARAMS_A  TSPFileCopyParams;

typedef SP_DEVINFO_DATA *PSPDevInfoData;

typedef SP_DEVINFO_DATA  TSPDevInfoData;

typedef SP_DEVICE_INTERFACE_DATA *PSPDeviceInterfaceData;

typedef SP_DEVICE_INTERFACE_DATA  TSPDeviceInterfaceData;

typedef SP_DEVICE_INTERFACE_DATA  TSPInterfaceDeviceData;

typedef SP_DEVICE_INTERFACE_DATA *PSPInterfaceDeviceData;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A *PSPDeviceInterfaceDetailDataA;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_W *PSPDeviceInterfaceDetailDataW;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A *PSPDeviceInterfaceDetailData;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A  TSPDeviceInterfaceDetailDataA;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_W  TSPDeviceInterfaceDetailDataW;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A  TSPDeviceInterfaceDetailData;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A  TSPInterfaceDeviceDetailDataA;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_W  TSPInterfaceDeviceDetailDataW;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A  TSPInterfaceDeviceDetailData;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A *PSPInterfaceDeviceDetailDataA;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_W *PSPInterfaceDeviceDetailDataW;

typedef SP_DEVICE_INTERFACE_DETAIL_DATA_A *PSPInterfaceDeviceDetailData;

typedef SP_DEVINFO_LIST_DETAIL_DATA_A *PSPDevInfoListDetailDataA;

typedef SP_DEVINFO_LIST_DETAIL_DATA_W *PSPDevInfoListDetailDataW;

typedef SP_DEVINFO_LIST_DETAIL_DATA_A *PSPDevInfoListDetailData;

typedef SP_DEVINFO_LIST_DETAIL_DATA_A  TSPDevInfoListDetailDataA;

typedef SP_DEVINFO_LIST_DETAIL_DATA_W  TSPDevInfoListDetailDataW;

typedef SP_DEVINFO_LIST_DETAIL_DATA_A  TSPDevInfoListDetailData;

typedef SP_DEVINSTALL_PARAMS_A *PSPDevInstallParamsA;

typedef SP_DEVINSTALL_PARAMS_W *PSPDevInstallParamsW;

typedef SP_DEVINSTALL_PARAMS_A *PSPDevInstallParams;

typedef SP_DEVINSTALL_PARAMS_A  TSPDevInstallParamsA;

typedef SP_DEVINSTALL_PARAMS_W  TSPDevInstallParamsW;

typedef SP_DEVINSTALL_PARAMS_A  TSPDevInstallParams;

typedef SP_CLASSINSTALL_HEADER *PSPClassInstallHeader;

typedef SP_CLASSINSTALL_HEADER  TSPClassInstallHeader;

typedef SP_ENABLECLASS_PARAMS *PSPEnableClassParams;

typedef SP_ENABLECLASS_PARAMS  TSPEnableClassParams;

typedef SP_MOVEDEV_PARAMS *PSPMoveDevParams;

typedef SP_MOVEDEV_PARAMS  TSPMoveDevParams;

typedef SP_PROPCHANGE_PARAMS *PSPPropChangeParams;

typedef SP_PROPCHANGE_PARAMS  TSPPropChangeParams;

typedef SP_REMOVEDEVICE_PARAMS *PSPRemoveDeviceParams;

typedef SP_REMOVEDEVICE_PARAMS  TSPRemoveDeviceParams;

typedef SP_UNREMOVEDEVICE_PARAMS *PSPUnremoveDeviceParams;

typedef SP_UNREMOVEDEVICE_PARAMS  TSPUnremoveDeviceParams;

typedef SP_SELECTDEVICE_PARAMS_A *PSPSelectDeviceParamsA;

typedef SP_SELECTDEVICE_PARAMS_W *PSPSelectDeviceParamsW;

typedef SP_SELECTDEVICE_PARAMS_A *PSPSelectDeviceParams;

typedef SP_SELECTDEVICE_PARAMS_A  TSPSelectdeviceParamsA;

typedef SP_SELECTDEVICE_PARAMS_W  TSPSelectdeviceParamsW;

typedef SP_SELECTDEVICE_PARAMS_A  TSPSelectdeviceParams;

typedef BOOL __stdcall (*PDetectProgressNotify)(void * ProgressNotifyParam, unsigned DetectComplete);

typedef SP_DETECTDEVICE_PARAMS *PSPDetectDeviceParams;

typedef SP_DETECTDEVICE_PARAMS  TSPDetectDeviceParams;

typedef SP_INSTALLWIZARD_DATA *PSPInstallWizardData;

typedef SP_INSTALLWIZARD_DATA  TSPInstallWizardData;

typedef SP_NEWDEVICEWIZARD_DATA *PSPNewDeviceWizardData;

typedef SP_NEWDEVICEWIZARD_DATA  TSPNewDeviceWizardData;

typedef SP_TROUBLESHOOTER_PARAMS_A *PSPTroubleShooterParamsA;

typedef SP_TROUBLESHOOTER_PARAMS_W *PSPTroubleShooterParamsW;

typedef SP_TROUBLESHOOTER_PARAMS_A *PSPTroubleShooterParams;

typedef SP_TROUBLESHOOTER_PARAMS_A  TSPTroubleShooterParamsA;

typedef SP_TROUBLESHOOTER_PARAMS_W  TSPTroubleShooterParamsW;

typedef SP_TROUBLESHOOTER_PARAMS_A  TSPTroubleShooterParams;

typedef SP_POWERMESSAGEWAKE_PARAMS_A *PSPPowerMessageWakeParamsA;

typedef SP_POWERMESSAGEWAKE_PARAMS_W *PSPPowerMessageWakeParamsW;

typedef SP_POWERMESSAGEWAKE_PARAMS_A *PSPPowerMessageWakeParams;

typedef SP_POWERMESSAGEWAKE_PARAMS_A  TSPPowerMessageWakeParamsA;

typedef SP_POWERMESSAGEWAKE_PARAMS_W  TSPPowerMessageWakeParamsW;

typedef SP_POWERMESSAGEWAKE_PARAMS_A  TSPPowerMessageWakeParams;

typedef SP_DRVINFO_DATA_V2_A *PSPDrvInfoDataV2A;

typedef SP_DRVINFO_DATA_V2_W *PSPDrvInfoDataV2W;

typedef SP_DRVINFO_DATA_V2_A *PSPDrvInfoDataV2;

typedef SP_DRVINFO_DATA_V2_A  TSPDrvInfoDataV2A;

typedef SP_DRVINFO_DATA_V2_W  TSPDrvInfoDataV2W;

typedef SP_DRVINFO_DATA_V2_A  TSPDrvInfoDataV2;

typedef SP_DRVINFO_DATA_V1_A *PSPDrvInfoDataV1A;

typedef SP_DRVINFO_DATA_V1_W *PSPDrvInfoDataV1W;

typedef SP_DRVINFO_DATA_V1_A *PSPDrvInfoDataV1;

typedef SP_DRVINFO_DATA_V1_A  TSPDrvInfoDataV1A;

typedef SP_DRVINFO_DATA_V1_W  TSPDrvInfoDataV1W;

typedef SP_DRVINFO_DATA_V1_A  TSPDrvInfoDataV1;

typedef SP_DRVINFO_DATA_V2_A  TSPDrvInfoDataA;

typedef SP_DRVINFO_DATA_V2_W  TSPDrvInfoDataW;

typedef SP_DRVINFO_DATA_V2_A  TSPDrvInfoData;

typedef SP_DRVINFO_DATA_V2_A *PSPDrvInfoDataA;

typedef SP_DRVINFO_DATA_V2_W *PSPDrvInfoDataW;

typedef SP_DRVINFO_DATA_V2_A *PSPDrvInfoData;

typedef SP_DRVINFO_DETAIL_DATA_A *PSPDrvInfoDetailDataA;

typedef SP_DRVINFO_DETAIL_DATA_W *PSPDrvInfoDetailDataW;

typedef SP_DRVINFO_DETAIL_DATA_A *PSPDrvInfoDetailData;

typedef SP_DRVINFO_DETAIL_DATA_A  TSPDrvInfoDetailDataA;

typedef SP_DRVINFO_DETAIL_DATA_W  TSPDrvInfoDetailDataW;

typedef SP_DRVINFO_DETAIL_DATA_A  TSPDrvInfoDetailData;

typedef SP_DRVINSTALL_PARAMS *PSPDrvInstallParams;

typedef SP_DRVINSTALL_PARAMS  TSPDrvInstallParams;

typedef unsigned __stdcall (*TSPDetsigCmpProc)(void * DeviceInfoSet, PSPDevInfoData NewDeviceData, PSPDevInfoData ExistingDeviceData, void * CompareContext);

typedef COINSTALLER_CONTEXT_DATA *PCoInstallerContextData;

typedef COINSTALLER_CONTEXT_DATA  TCoInstallerContextData;

typedef SP_CLASSIMAGELIST_DATA *PSPClassImageListData;

typedef SP_CLASSIMAGELIST_DATA  TSPClassImageListData;

typedef SP_PROPSHEETPAGE_REQUEST *PSPPropSheetPageRequest;

typedef SP_PROPSHEETPAGE_REQUEST  TSPPropSheetPageRequest;

typedef SP_BACKUP_QUEUE_PARAMS_A *PSPBackupQueueParamsA;

typedef SP_BACKUP_QUEUE_PARAMS_W *PSPBackupQueueParamsW;

typedef SP_BACKUP_QUEUE_PARAMS_A *PSPBackupQueueParams;

typedef SP_BACKUP_QUEUE_PARAMS_A  TSPBackupQueueParamsA;

typedef SP_BACKUP_QUEUE_PARAMS_W  TSPBackupQueueParamsW;

typedef SP_BACKUP_QUEUE_PARAMS_A  TSPBackupQueueParams;

typedef BOOL __stdcall (*TSetupGetInfInformationA)(void * InfSpec, unsigned SearchControl, PSPInfInformation ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetInfInformationW)(void * InfSpec, unsigned SearchControl, PSPInfInformation ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetInfInformation)(void * InfSpec, unsigned SearchControl, PSPInfInformation ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryInfFileInformationA)(SP_INF_INFORMATION &InfInformation, unsigned InfIndex, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryInfFileInformationW)(SP_INF_INFORMATION &InfInformation, unsigned InfIndex, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryInfFileInformation)(SP_INF_INFORMATION &InfInformation, unsigned InfIndex, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryInfVersionInformationA)(SP_INF_INFORMATION &InfInformation, unsigned InfIndex, const char * Key, const char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryInfVersionInformationW)(SP_INF_INFORMATION &InfInformation, unsigned InfIndex, const wchar_t * Key, const wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryInfVersionInformation)(SP_INF_INFORMATION &InfInformation, unsigned InfIndex, const char * Key, const char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetInfFileListA)(const char * DirectoryPath, unsigned InfStyle, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetInfFileListW)(const wchar_t * DirectoryPath, unsigned InfStyle, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetInfFileList)(const char * DirectoryPath, unsigned InfStyle, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef void * __stdcall (*TSetupOpenInfFileA)(const char * FileName, const char * InfClass, unsigned InfStyle, PUINT ErrorLine);

typedef void * __stdcall (*TSetupOpenInfFileW)(const wchar_t * FileName, const wchar_t * InfClass, unsigned InfStyle, PUINT ErrorLine);

typedef void * __stdcall (*TSetupOpenInfFile)(const char * FileName, const char * InfClass, unsigned InfStyle, PUINT ErrorLine);

typedef void * __stdcall (*TSetupOpenMasterInf)(void);

typedef BOOL __stdcall (*TSetupOpenAppendInfFileA)(const char * FileName, void * InfHandle, PUINT ErrorLine);

typedef BOOL __stdcall (*TSetupOpenAppendInfFileW)(const wchar_t * FileName, void * InfHandle, PUINT ErrorLine);

typedef BOOL __stdcall (*TSetupOpenAppendInfFile)(const char * FileName, void * InfHandle, PUINT ErrorLine);

typedef void __stdcall (*TSetupCloseInfFile)(void * InfHandle);

typedef BOOL __stdcall (*TSetupFindFirstLineA)(void * InfHandle, char * Section, char * Key, INFCONTEXT &Context);

typedef BOOL __stdcall (*TSetupFindFirstLineW)(void * InfHandle, wchar_t * Section, wchar_t * Key, INFCONTEXT &Context);

typedef BOOL __stdcall (*TSetupFindFirstLine)(void * InfHandle, char * Section, char * Key, INFCONTEXT &Context);

typedef BOOL __stdcall (*TSetupFindNextLine)(INFCONTEXT &ContextIn, INFCONTEXT &ContextOut);

typedef BOOL __stdcall (*TSetupFindNextMatchLineA)(INFCONTEXT &ContextIn, char * Key, INFCONTEXT &ContextOut);

typedef BOOL __stdcall (*TSetupFindNextMatchLineW)(INFCONTEXT &ContextIn, wchar_t * Key, INFCONTEXT &ContextOut);

typedef BOOL __stdcall (*TSetupFindNextMatchLine)(INFCONTEXT &ContextIn, char * Key, INFCONTEXT &ContextOut);

typedef BOOL __stdcall (*TSetupGetLineByIndexA)(void * InfHandle, char * Section, unsigned Index, INFCONTEXT &Context);

typedef BOOL __stdcall (*TSetupGetLineByIndexW)(void * InfHandle, wchar_t * Section, unsigned Index, INFCONTEXT &Context);

typedef BOOL __stdcall (*TSetupGetLineByIndex)(void * InfHandle, char * Section, unsigned Index, INFCONTEXT &Context);

typedef int __stdcall (*TSetupGetLineCountA)(void * InfHandle, char * Section);

typedef int __stdcall (*TSetupGetLineCountW)(void * InfHandle, wchar_t * Section);

typedef int __stdcall (*TSetupGetLineCount)(void * InfHandle, char * Section);

typedef BOOL __stdcall (*TSetupGetLineTextA)(PInfContext Context, void * InfHandle, char * Section, char * Key, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetLineTextW)(PInfContext Context, void * InfHandle, wchar_t * Section, wchar_t * Key, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetLineText)(PInfContext Context, void * InfHandle, char * Section, char * Key, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef unsigned __stdcall (*TSetupGetFieldCount)(INFCONTEXT &Context);

typedef BOOL __stdcall (*TSetupGetStringFieldA)(INFCONTEXT &Context, unsigned FieldIndex, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetStringFieldW)(INFCONTEXT &Context, unsigned FieldIndex, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetStringField)(INFCONTEXT &Context, unsigned FieldIndex, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetIntField)(INFCONTEXT &Context, unsigned FieldIndex, int &IntegerValue);

typedef BOOL __stdcall (*TSetupGetMultiSzFieldA)(INFCONTEXT &Context, unsigned FieldIndex, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetMultiSzFieldW)(INFCONTEXT &Context, unsigned FieldIndex, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetMultiSzField)(INFCONTEXT &Context, unsigned FieldIndex, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetBinaryField)(INFCONTEXT &Context, unsigned FieldIndex, System::PByte ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef unsigned __stdcall (*TSetupGetFileCompressionInfoA)(const char * SourceFileName, char * &ActualSourceFileName, unsigned &SourceFileSize, unsigned &TargetFileSize, unsigned &CompressionType);

typedef unsigned __stdcall (*TSetupGetFileCompressionInfoW)(const wchar_t * SourceFileName, wchar_t * &ActualSourceFileName, unsigned &SourceFileSize, unsigned &TargetFileSize, unsigned &CompressionType);

typedef unsigned __stdcall (*TSetupGetFileCompressionInfo)(const char * SourceFileName, char * &ActualSourceFileName, unsigned &SourceFileSize, unsigned &TargetFileSize, unsigned &CompressionType);

typedef unsigned __stdcall (*TSetupDecompressOrCopyFileA)(const char * SourceFileName, const char * TargetFileName, unsigned &CompressionType);

typedef unsigned __stdcall (*TSetupDecompressOrCopyFileW)(const wchar_t * SourceFileName, const wchar_t * TargetFileName, unsigned &CompressionType);

typedef unsigned __stdcall (*TSetupDecompressOrCopyFile)(const char * SourceFileName, const char * TargetFileName, unsigned &CompressionType);

typedef BOOL __stdcall (*TSetupGetSourceFileLocationA)(void * InfHandle, PInfContext InfContext, const char * FileName, unsigned &SourceId, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetSourceFileLocationW)(void * InfHandle, PInfContext InfContext, const wchar_t * FileName, unsigned &SourceId, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetSourceFileLocation)(void * InfHandle, PInfContext InfContext, const char * FileName, unsigned &SourceId, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetSourceFileSizeA)(void * InfHandle, PInfContext InfContext, const char * FileName, const char * Section, unsigned &FileSize, unsigned RoundingFactor);

typedef BOOL __stdcall (*TSetupGetSourceFileSizeW)(void * InfHandle, PInfContext InfContext, const wchar_t * FileName, const wchar_t * Section, unsigned &FileSize, unsigned RoundingFactor);

typedef BOOL __stdcall (*TSetupGetSourceFileSize)(void * InfHandle, PInfContext InfContext, const char * FileName, const char * Section, unsigned &FileSize, unsigned RoundingFactor);

typedef BOOL __stdcall (*TSetupGetTargetPathA)(void * InfHandle, PInfContext InfContext, const char * Section, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetTargetPathW)(void * InfHandle, PInfContext InfContext, const wchar_t * Section, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetTargetPath)(void * InfHandle, PInfContext InfContext, const char * Section, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupSetSourceListA)(unsigned Flags, PPASTR SourceList, unsigned SourceCount);

typedef BOOL __stdcall (*TSetupSetSourceListW)(unsigned Flags, PPWSTR SourceList, unsigned SourceCount);

typedef BOOL __stdcall (*TSetupSetSourceList)(unsigned Flags, PPSTR SourceList, unsigned SourceCount);

typedef BOOL __stdcall (*TSetupCancelTemporarySourceList)(void);

typedef BOOL __stdcall (*TSetupAddToSourceListA)(unsigned Flags, const char * Source);

typedef BOOL __stdcall (*TSetupAddToSourceListW)(unsigned Flags, const wchar_t * Source);

typedef BOOL __stdcall (*TSetupAddToSourceList)(unsigned Flags, const char * Source);

typedef BOOL __stdcall (*TSetupRemoveFromSourceListA)(unsigned Flags, const char * Source);

typedef BOOL __stdcall (*TSetupRemoveFromSourceListW)(unsigned Flags, const wchar_t * Source);

typedef BOOL __stdcall (*TSetupRemoveFromSourceList)(unsigned Flags, const char * Source);

typedef BOOL __stdcall (*TSetupQuerySourceListA)(unsigned Flags, PPASTR &List, unsigned &Count);

typedef BOOL __stdcall (*TSetupQuerySourceListW)(unsigned Flags, PPWSTR &List, unsigned &Count);

typedef BOOL __stdcall (*TSetupQuerySourceList)(unsigned Flags, PPSTR &List, unsigned &Count);

typedef BOOL __stdcall (*TSetupFreeSourceListA)(PPWSTR &List, unsigned Count);

typedef BOOL __stdcall (*TSetupFreeSourceListW)(PPASTR &List, unsigned Count);

typedef BOOL __stdcall (*TSetupFreeSourceList)(PPSTR &List, unsigned Count);

typedef unsigned __stdcall (*TSetupPromptForDiskA)(HWND hwndParent, const char * DialogTitle, const char * DiskName, const char * PathToSource, const char * FileSought, const char * TagFile, unsigned DiskPromptStyle, char * PathBuffer, unsigned PathBufferSize, unsigned &PathRequiredSize);

typedef unsigned __stdcall (*TSetupPromptForDiskW)(HWND hwndParent, const wchar_t * DialogTitle, const wchar_t * DiskName, const wchar_t * PathToSource, const wchar_t * FileSought, const wchar_t * TagFile, unsigned DiskPromptStyle, wchar_t * PathBuffer, unsigned PathBufferSize, unsigned &PathRequiredSize);

typedef unsigned __stdcall (*TSetupPromptForDisk)(HWND hwndParent, const char * DialogTitle, const char * DiskName, const char * PathToSource, const char * FileSought, const char * TagFile, unsigned DiskPromptStyle, char * PathBuffer, unsigned PathBufferSize, unsigned &PathRequiredSize);

typedef unsigned __stdcall (*TSetupCopyErrorA)(HWND hwndParent, const char * DialogTitle, const char * DiskName, const char * PathToSource, const char * SourceFile, const char * TargetPathFile, unsigned Win32ErrorCode, unsigned Style, char * PathBuffer, unsigned PathBufferSize, PDWORD PathRequiredSize);

typedef unsigned __stdcall (*TSetupCopyErrorW)(HWND hwndParent, const wchar_t * DialogTitle, const wchar_t * DiskName, const wchar_t * PathToSource, const wchar_t * SourceFile, const wchar_t * TargetPathFile, unsigned Win32ErrorCode, unsigned Style, wchar_t * PathBuffer, unsigned PathBufferSize, PDWORD PathRequiredSize);

typedef unsigned __stdcall (*TSetupCopyError)(HWND hwndParent, const char * DialogTitle, const char * DiskName, const char * PathToSource, const char * SourceFile, const char * TargetPathFile, unsigned Win32ErrorCode, unsigned Style, char * PathBuffer, unsigned PathBufferSize, PDWORD PathRequiredSize);

typedef unsigned __stdcall (*TSetupRenameErrorA)(HWND hwndParent, const char * DialogTitle, const char * SourceFile, const char * TargetFile, unsigned Win32ErrorCode, unsigned Style);

typedef unsigned __stdcall (*TSetupRenameErrorW)(HWND hwndParent, const wchar_t * DialogTitle, const wchar_t * SourceFile, const wchar_t * TargetFile, unsigned Win32ErrorCode, unsigned Style);

typedef unsigned __stdcall (*TSetupRenameError)(HWND hwndParent, const char * DialogTitle, const char * SourceFile, const char * TargetFile, unsigned Win32ErrorCode, unsigned Style);

typedef unsigned __stdcall (*TSetupDeleteErrorA)(HWND hwndParent, const char * DialogTitle, const char * File_, unsigned Win32ErrorCode, unsigned Style);

typedef unsigned __stdcall (*TSetupDeleteErrorW)(HWND hwndParent, const wchar_t * DialogTitle, const wchar_t * File_, unsigned Win32ErrorCode, unsigned Style);

typedef unsigned __stdcall (*TSetupDeleteError)(HWND hwndParent, const char * DialogTitle, const char * File_, unsigned Win32ErrorCode, unsigned Style);

typedef BOOL __stdcall (*TSetupSetDirectoryIdA)(void * InfHandle, unsigned Id, const char * Directory);

typedef BOOL __stdcall (*TSetupSetDirectoryIdW)(void * InfHandle, unsigned Id, const wchar_t * Directory);

typedef BOOL __stdcall (*TSetupSetDirectoryId)(void * InfHandle, unsigned Id, const char * Directory);

typedef BOOL __stdcall (*TSetupSetDirectoryIdExA)(void * InfHandle, unsigned Id, const char * Directory, unsigned Flags, unsigned Reserved1, void * Reserved2);

typedef BOOL __stdcall (*TSetupSetDirectoryIdExW)(void * InfHandle, unsigned Id, const wchar_t * Directory, unsigned Flags, unsigned Reserved1, void * Reserved2);

typedef BOOL __stdcall (*TSetupSetDirectoryIdEx)(void * InfHandle, unsigned Id, const char * Directory, unsigned Flags, unsigned Reserved1, void * Reserved2);

typedef BOOL __stdcall (*TSetupGetSourceInfoA)(void * InfHandle, unsigned SourceId, unsigned InfoDesired, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetSourceInfoW)(void * InfHandle, unsigned SourceId, unsigned InfoDesired, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupGetSourceInfo)(void * InfHandle, unsigned SourceId, unsigned InfoDesired, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupInstallFileA)(void * InfHandle, PInfContext InfContext, const char * SourceFile, const char * SourcePathRoot, const char * DestinationName, unsigned CopyStyle, TSPFileCallbackA CopyMsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupInstallFileW)(void * InfHandle, PInfContext InfContext, const wchar_t * SourceFile, const wchar_t * SourcePathRoot, const wchar_t * DestinationName, unsigned CopyStyle, TSPFileCallbackW CopyMsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupInstallFile)(void * InfHandle, PInfContext InfContext, const char * SourceFile, const char * SourcePathRoot, const char * DestinationName, unsigned CopyStyle, TSPFileCallbackA CopyMsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupInstallFileExA)(void * InfHandle, PInfContext InfContext, const char * SourceFile, const char * SourcePathRoot, const char * DestinationName, unsigned CopyStyle, TSPFileCallbackA CopyMsgHandler, void * Context, BOOL &FileWasInUse);

typedef BOOL __stdcall (*TSetupInstallFileExW)(void * InfHandle, PInfContext InfContext, const wchar_t * SourceFile, const wchar_t * SourcePathRoot, const wchar_t * DestinationName, unsigned CopyStyle, TSPFileCallbackW CopyMsgHandler, void * Context, BOOL &FileWasInUse);

typedef BOOL __stdcall (*TSetupInstallFileEx)(void * InfHandle, PInfContext InfContext, const char * SourceFile, const char * SourcePathRoot, const char * DestinationName, unsigned CopyStyle, TSPFileCallbackA CopyMsgHandler, void * Context, BOOL &FileWasInUse);

typedef void * __stdcall (*TSetupOpenFileQueue)(void);

typedef BOOL __stdcall (*TSetupCloseFileQueue)(void * QueueHandle);

typedef BOOL __stdcall (*TSetupSetPlatformPathOverrideA)(const char * Override_);

typedef BOOL __stdcall (*TSetupSetPlatformPathOverrideW)(const wchar_t * Override_);

typedef BOOL __stdcall (*TSetupSetPlatformPathOverride)(const char * Override_);

typedef BOOL __stdcall (*TSetupQueueCopyA)(void * QueueHandle, const char * SourceRootPath, const char * SourcePath, const char * SourceFilename, const char * SourceDescription, const char * SourceTagfile, const char * TargetDirectory, const char * TargetFilename, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueCopyW)(void * QueueHandle, const wchar_t * SourceRootPath, const wchar_t * SourcePath, const wchar_t * SourceFilename, const wchar_t * SourceDescription, const wchar_t * SourceTagfile, const wchar_t * TargetDirectory, const wchar_t * TargetFilename, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueCopy)(void * QueueHandle, const char * SourceRootPath, const char * SourcePath, const char * SourceFilename, const char * SourceDescription, const char * SourceTagfile, const char * TargetDirectory, const char * TargetFilename, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueDefaultCopyA)(void * QueueHandle, void * InfHandle, const char * SourceRootPath, const char * SourceFilename, const char * TargetFilename, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueDefaultCopyW)(void * QueueHandle, void * InfHandle, const wchar_t * SourceRootPath, const wchar_t * SourceFilename, const wchar_t * TargetFilename, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueDefaultCopy)(void * QueueHandle, void * InfHandle, const char * SourceRootPath, const char * SourceFilename, const char * TargetFilename, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueCopySectionA)(void * QueueHandle, const char * SourceRootPath, void * InfHandle, void * ListInfHandle, const char * Section, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueCopySectionW)(void * QueueHandle, const wchar_t * SourceRootPath, void * InfHandle, void * ListInfHandle, const wchar_t * Section, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueCopySection)(void * QueueHandle, const char * SourceRootPath, void * InfHandle, void * ListInfHandle, const char * Section, unsigned CopyStyle);

typedef BOOL __stdcall (*TSetupQueueDeleteA)(void * QueueHandle, const char * PathPart1, const char * PathPart2);

typedef BOOL __stdcall (*TSetupQueueDeleteW)(void * QueueHandle, const wchar_t * PathPart1, const wchar_t * PathPart2);

typedef BOOL __stdcall (*TSetupQueueDelete)(void * QueueHandle, const char * PathPart1, const char * PathPart2);

typedef BOOL __stdcall (*TSetupQueueDeleteSectionA)(void * QueueHandle, void * InfHandle, void * ListInfHandle, const char * Section);

typedef BOOL __stdcall (*TSetupQueueDeleteSectionW)(void * QueueHandle, void * InfHandle, void * ListInfHandle, const wchar_t * Section);

typedef BOOL __stdcall (*TSetupQueueDeleteSection)(void * QueueHandle, void * InfHandle, void * ListInfHandle, const char * Section);

typedef BOOL __stdcall (*TSetupQueueRenameA)(void * QueueHandle, const char * SourcePath, const char * SourceFilename, const char * TargetPath, const char * TargetFilename);

typedef BOOL __stdcall (*TSetupQueueRenameW)(void * QueueHandle, const wchar_t * SourcePath, const wchar_t * SourceFilename, const wchar_t * TargetPath, const wchar_t * TargetFilename);

typedef BOOL __stdcall (*TSetupQueueRename)(void * QueueHandle, const char * SourcePath, const char * SourceFilename, const char * TargetPath, const char * TargetFilename);

typedef BOOL __stdcall (*TSetupQueueRenameSectionA)(void * QueueHandle, void * InfHandle, void * ListInfHandle, const char * Section);

typedef BOOL __stdcall (*TSetupQueueRenameSectionW)(void * QueueHandle, void * InfHandle, void * ListInfHandle, const wchar_t * Section);

typedef BOOL __stdcall (*TSetupQueueRenameSection)(void * QueueHandle, void * InfHandle, void * ListInfHandle, const char * Section);

typedef BOOL __stdcall (*TSetupCommitFileQueueA)(HWND Owner, void * QueueHandle, TSPFileCallbackA MsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupCommitFileQueueW)(HWND Owner, void * QueueHandle, TSPFileCallbackW MsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupCommitFileQueue)(HWND Owner, void * QueueHandle, TSPFileCallbackA MsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupScanFileQueueA)(void * FileQueue, unsigned Flags, HWND Window, TSPFileCallbackA CallbackRoutine, void * CallbackContext, unsigned &Result);

typedef BOOL __stdcall (*TSetupScanFileQueueW)(void * FileQueue, unsigned Flags, HWND Window, TSPFileCallbackW CallbackRoutine, void * CallbackContext, unsigned &Result);

typedef BOOL __stdcall (*TSetupScanFileQueue)(void * FileQueue, unsigned Flags, HWND Window, TSPFileCallbackA CallbackRoutine, void * CallbackContext, unsigned &Result);

typedef BOOL __stdcall (*TSetupCopyOEMInfA)(const char * SourceInfFileName, const char * OEMSourceMediaLocation, unsigned OEMSourceMediaType, unsigned CopyStyle, char * DestinationInfFileName, unsigned DestinationInfFileNameSize, PDWORD RequiredSize, PPASTR DestinationInfFileNameComponent);

typedef BOOL __stdcall (*TSetupCopyOEMInfW)(const wchar_t * SourceInfFileName, const wchar_t * OEMSourceMediaLocation, unsigned OEMSourceMediaType, unsigned CopyStyle, wchar_t * DestinationInfFileName, unsigned DestinationInfFileNameSize, PDWORD RequiredSize, PPWSTR DestinationInfFileNameComponent);

typedef BOOL __stdcall (*TSetupCopyOEMInf)(const char * SourceInfFileName, const char * OEMSourceMediaLocation, unsigned OEMSourceMediaType, unsigned CopyStyle, char * DestinationInfFileName, unsigned DestinationInfFileNameSize, PDWORD RequiredSize, PPSTR DestinationInfFileNameComponent);

typedef void * __stdcall (*TSetupCreateDiskSpaceListA)(void * Reserved1, unsigned Reserved2, unsigned Flags);

typedef void * __stdcall (*TSetupCreateDiskSpaceListW)(void * Reserved1, unsigned Reserved2, unsigned Flags);

typedef void * __stdcall (*TSetupCreateDiskSpaceList)(void * Reserved1, unsigned Reserved2, unsigned Flags);

typedef void * __stdcall (*TSetupDuplicateDiskSpaceListA)(void * DiskSpace, void * Reserved1, unsigned Reserved2, unsigned Flags);

typedef void * __stdcall (*TSetupDuplicateDiskSpaceListW)(void * DiskSpace, void * Reserved1, unsigned Reserved2, unsigned Flags);

typedef void * __stdcall (*TSetupDuplicateDiskSpaceList)(void * DiskSpace, void * Reserved1, unsigned Reserved2, unsigned Flags);

typedef BOOL __stdcall (*TSetupDestroyDiskSpaceList)(void * DiskSpace);

typedef BOOL __stdcall (*TSetupQueryDrivesInDiskSpaceListA)(void * DiskSpace, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryDrivesInDiskSpaceListW)(void * DiskSpace, wchar_t * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryDrivesInDiskSpaceList)(void * DiskSpace, char * ReturnBuffer, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQuerySpaceRequiredOnDriveA)(void * DiskSpace, const char * DriveSpec, __int64 &SpaceRequired, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupQuerySpaceRequiredOnDriveW)(void * DiskSpace, const wchar_t * DriveSpec, __int64 &SpaceRequired, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupQuerySpaceRequiredOnDrive)(void * DiskSpace, const char * DriveSpec, __int64 &SpaceRequired, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAdjustDiskSpaceListA)(void * DiskSpace, const char * DriveRoot, __int64 Amount, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAdjustDiskSpaceListW)(void * DiskSpace, const wchar_t * DriveRoot, __int64 Amount, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAdjustDiskSpaceList)(void * DiskSpace, const char * DriveRoot, __int64 Amount, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddToDiskSpaceListA)(void * DiskSpace, const char * TargetFilespec, __int64 FileSize, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddToDiskSpaceListW)(void * DiskSpace, const wchar_t * TargetFilespec, __int64 FileSize, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddToDiskSpaceList)(void * DiskSpace, const char * TargetFilespec, __int64 FileSize, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddSectionToDiskSpaceListA)(void * DiskSpace, void * InfHandle, void * ListInfHandle, const char * SectionName, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddSectionToDiskSpaceListW)(void * DiskSpace, void * InfHandle, void * ListInfHandle, const wchar_t * SectionName, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddSectionToDiskSpaceList)(void * DiskSpace, void * InfHandle, void * ListInfHandle, const char * SectionName, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddInstallSectionToDiskSpaceListA)(void * DiskSpace, void * InfHandle, void * LayoutInfHandle, const char * SectionName, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddInstallSectionToDiskSpaceListW)(void * DiskSpace, void * InfHandle, void * LayoutInfHandle, const wchar_t * SectionName, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupAddInstallSectionToDiskSpaceList)(void * DiskSpace, void * InfHandle, void * LayoutInfHandle, const char * SectionName, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveFromDiskSpaceListA)(void * DiskSpace, const char * TargetFilespec, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveFromDiskSpaceListW)(void * DiskSpace, const wchar_t * TargetFilespec, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveFromDiskSpaceList)(void * DiskSpace, const char * TargetFilespec, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveSectionFromDiskSpaceListA)(void * DiskSpace, void * InfHandle, void * ListInfHandle, const char * SectionName, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveSectionFromDiskSpaceListW)(void * DiskSpace, void * InfHandle, void * ListInfHandle, const wchar_t * SectionName, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveSectionFromDiskSpaceList)(void * DiskSpace, void * InfHandle, void * ListInfHandle, const char * SectionName, unsigned Operation, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveInstallSectionFromDiskSpaceListA)(void * DiskSpace, void * InfHandle, void * LayoutInfHandle, const char * SectionName, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveInstallSectionFromDiskSpaceListW)(void * DiskSpace, void * InfHandle, void * LayoutInfHandle, const wchar_t * SectionName, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupRemoveInstallSectionFromDiskSpaceList)(void * DiskSpace, void * InfHandle, void * LayoutInfHandle, const char * SectionName, void * Reserved1, unsigned Reserved2);

typedef BOOL __stdcall (*TSetupIterateCabinetA)(const char * CabinetFile, unsigned Reserved, TSPFileCallbackA MsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupIterateCabinetW)(const wchar_t * CabinetFile, unsigned Reserved, TSPFileCallbackW MsgHandler, void * Context);

typedef BOOL __stdcall (*TSetupIterateCabinet)(const char * CabinetFile, unsigned Reserved, TSPFileCallbackA MsgHandler, void * Context);

typedef int __stdcall (*TSetupPromptReboot)(void * FileQueue, HWND Owner, BOOL ScanOnly);

typedef void * __stdcall (*TSetupInitDefaultQueueCallback)(HWND OwnerWindow);

typedef void * __stdcall (*TSetupInitDefaultQueueCallbackEx)(HWND OwnerWindow, HWND AlternateProgressWindow, unsigned ProgressMessage, unsigned Reserved1, void * Reserved2);

typedef void __stdcall (*TSetupTermDefaultQueueCallback)(void * Context);

typedef unsigned __stdcall (*TSetupDefaultQueueCallbackA)(void * Context, unsigned Notification, unsigned Param1, unsigned Param2);

typedef unsigned __stdcall (*TSetupDefaultQueueCallbackW)(void * Context, unsigned Notification, unsigned Param1, unsigned Param2);

typedef unsigned __stdcall (*TSetupDefaultQueueCallback)(void * Context, unsigned Notification, unsigned Param1, unsigned Param2);

typedef BOOL __stdcall (*TSetupInstallFromInfSectionA)(HWND Owner, void * InfHandle, const char * SectionName, unsigned Flags, HKEY RelativeKeyRoot, const char * SourceRootPath, unsigned CopyFlags, TSPFileCallbackA MsgHandler, void * Context, void * DeviceInfoSet, PSPDevInfoData DeviceIn);

typedef BOOL __stdcall (*TSetupInstallFromInfSectionW)(HWND Owner, void * InfHandle, const wchar_t * SectionName, unsigned Flags, HKEY RelativeKeyRoot, const wchar_t * SourceRootPath, unsigned CopyFlags, TSPFileCallbackW MsgHandler, void * Context, void * DeviceInfoSet, PSPDevInfoData DeviceIn);

typedef BOOL __stdcall (*TSetupInstallFromInfSection)(HWND Owner, void * InfHandle, const char * SectionName, unsigned Flags, HKEY RelativeKeyRoot, const char * SourceRootPath, unsigned CopyFlags, TSPFileCallbackA MsgHandler, void * Context, void * DeviceInfoSet, PSPDevInfoData DeviceIn);

typedef BOOL __stdcall (*TSetupInstallFilesFromInfSectionA)(void * InfHandle, void * LayoutInfHandle, void * FileQueue, const char * SectionName, const char * SourceRootPath, unsigned CopyFlags);

typedef BOOL __stdcall (*TSetupInstallFilesFromInfSectionW)(void * InfHandle, void * LayoutInfHandle, void * FileQueue, const wchar_t * SectionName, const wchar_t * SourceRootPath, unsigned CopyFlags);

typedef BOOL __stdcall (*TSetupInstallFilesFromInfSection)(void * InfHandle, void * LayoutInfHandle, void * FileQueue, const char * SectionName, const char * SourceRootPath, unsigned CopyFlags);

typedef BOOL __stdcall (*TSetupInstallServicesFromInfSectionA)(void * InfHandle, const char * SectionName, unsigned Flags);

typedef BOOL __stdcall (*TSetupInstallServicesFromInfSectionW)(void * InfHandle, const wchar_t * SectionName, unsigned Flags);

typedef BOOL __stdcall (*TSetupInstallServicesFromInfSection)(void * InfHandle, const char * SectionName, unsigned Flags);

typedef BOOL __stdcall (*TSetupInstallServicesFromInfSectionExA)(void * InfHandle, const char * SectionName, unsigned Flags, void * DeviceInfoSet, const SP_DEVINFO_DATA DeviceInfoData, void * Reserved1, void * Reserved2);

typedef BOOL __stdcall (*TSetupInstallServicesFromInfSectionExW)(void * InfHandle, const wchar_t * SectionName, unsigned Flags, void * DeviceInfoSet, const SP_DEVINFO_DATA DeviceInfoData, void * Reserved1, void * Reserved2);

typedef BOOL __stdcall (*TSetupInstallServicesFromInfSectionEx)(void * InfHandle, const char * SectionName, unsigned Flags, void * DeviceInfoSet, const SP_DEVINFO_DATA DeviceInfoData, void * Reserved1, void * Reserved2);

typedef void * __stdcall (*TSetupInitializeFileLogA)(const char * LogFileName, unsigned Flags);

typedef void * __stdcall (*TSetupInitializeFileLogW)(const wchar_t * LogFileName, unsigned Flags);

typedef void * __stdcall (*TSetupInitializeFileLog)(const char * LogFileName, unsigned Flags);

typedef BOOL __stdcall (*TSetupTerminateFileLog)(void * FileLogHandle);

typedef BOOL __stdcall (*TSetupLogFileA)(void * FileLogHandle, const char * LogSectionName, const char * SourceFilename, const char * TargetFilename, unsigned Checksum, char * DiskTagfile, char * DiskDescription, char * OtherInfo, unsigned Flags);

typedef BOOL __stdcall (*TSetupLogFileW)(void * FileLogHandle, const wchar_t * LogSectionName, const wchar_t * SourceFilename, const wchar_t * TargetFilename, unsigned Checksum, wchar_t * DiskTagfile, wchar_t * DiskDescription, wchar_t * OtherInfo, unsigned Flags);

typedef BOOL __stdcall (*TSetupLogFile)(void * FileLogHandle, const char * LogSectionName, const char * SourceFilename, const char * TargetFilename, unsigned Checksum, char * DiskTagfile, char * DiskDescription, char * OtherInfo, unsigned Flags);

typedef BOOL __stdcall (*TSetupRemoveFileLogEntryA)(void * FileLogHandle, const char * LogSectionName, const char * TargetFilename);

typedef BOOL __stdcall (*TSetupRemoveFileLogEntryW)(void * FileLogHandle, const wchar_t * LogSectionName, const wchar_t * TargetFilename);

typedef BOOL __stdcall (*TSetupRemoveFileLogEntry)(void * FileLogHandle, const char * LogSectionName, const char * TargetFilename);

typedef BOOL __stdcall (*TSetupQueryFileLogA)(void * FileLogHandle, const char * LogSectionName, const char * TargetFilename, unsigned DesiredInfo, char * DataOut, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryFileLogW)(void * FileLogHandle, const wchar_t * LogSectionName, const wchar_t * TargetFilename, unsigned DesiredInfo, wchar_t * DataOut, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupQueryFileLog)(void * FileLogHandle, const char * LogSectionName, const char * TargetFilename, unsigned DesiredInfo, char * DataOut, unsigned ReturnBufferSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupOpenLog)(BOOL Erase);

typedef BOOL __stdcall (*TSetupLogErrorA)(const char * MessageString, unsigned Severity);

typedef BOOL __stdcall (*TSetupLogErrorW)(const wchar_t * MessageString, unsigned Severity);

typedef BOOL __stdcall (*TSetupLogError)(const char * MessageString, unsigned Severity);

typedef void __stdcall (*TSetupCloseLog)(void);

typedef void * __stdcall (*TSetupDiCreateDeviceInfoList)(System::PGUID ClassGuid, HWND hwndParent);

typedef void * __stdcall (*TSetupDiCreateDeviceInfoListExA)(System::PGUID ClassGuid, HWND hwndParent, const char * MachineName, void * Reserved);

typedef void * __stdcall (*TSetupDiCreateDeviceInfoListExW)(System::PGUID ClassGuid, HWND hwndParent, const wchar_t * MachineName, void * Reserved);

typedef void * __stdcall (*TSetupDiCreateDeviceInfoListEx)(System::PGUID ClassGuid, HWND hwndParent, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetDeviceInfoListClass)(void * DeviceInfoSet, GUID &ClassGuid);

typedef BOOL __stdcall (*TSetupDiGetDeviceInfoListDetailA)(void * DeviceInfoSet, SP_DEVINFO_LIST_DETAIL_DATA_A &DeviceInfoSetDetailData);

typedef BOOL __stdcall (*TSetupDiGetDeviceInfoListDetailW)(void * DeviceInfoSet, SP_DEVINFO_LIST_DETAIL_DATA_W &DeviceInfoSetDetailData);

typedef BOOL __stdcall (*TSetupDiGetDeviceInfoListDetail)(void * DeviceInfoSet, SP_DEVINFO_LIST_DETAIL_DATA_A &DeviceInfoSetDetailData);

typedef BOOL __stdcall (*TSetupDiCreateDeviceInfoA)(void * DeviceInfoSet, const char * DeviceName, GUID &ClassGuid, const char * DeviceDescription, HWND hwndParent, unsigned CreationFlags, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiCreateDeviceInfoW)(void * DeviceInfoSet, const wchar_t * DeviceName, GUID &ClassGuid, const wchar_t * DeviceDescription, HWND hwndParent, unsigned CreationFlags, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiCreateDeviceInfo)(void * DeviceInfoSet, const char * DeviceName, GUID &ClassGuid, const char * DeviceDescription, HWND hwndParent, unsigned CreationFlags, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiOpenDeviceInfoA)(void * DeviceInfoSet, const char * DeviceInstanceId, HWND hwndParent, unsigned OpenFlags, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiOpenDeviceInfoW)(void * DeviceInfoSet, const wchar_t * DeviceInstanceId, HWND hwndParent, unsigned OpenFlags, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiOpenDeviceInfo)(void * DeviceInfoSet, const char * DeviceInstanceId, HWND hwndParent, unsigned OpenFlags, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiGetDeviceInstanceIdA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, char * DeviceInstanceId, unsigned DeviceInstanceIdSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetDeviceInstanceIdW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, wchar_t * DeviceInstanceId, unsigned DeviceInstanceIdSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetDeviceInstanceId)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, char * DeviceInstanceId, unsigned DeviceInstanceIdSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiDeleteDeviceInfo)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiEnumDeviceInfo)(void * DeviceInfoSet, unsigned MemberIndex, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiDestroyDeviceInfoList)(void * DeviceInfoSet);

typedef BOOL __stdcall (*TSetupDiEnumDeviceInterfaces)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, const GUID &InterfaceClassGuid, unsigned MemberIndex, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiEnumInterfaceDevice)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, GUID &InterfaceClassGuid, unsigned MemberIndex, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiCreateDeviceInterfaceA)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, GUID &InterfaceClassGuid, const char * ReferenceString, unsigned CreationFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiCreateDeviceInterfaceW)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, GUID &InterfaceClassGuid, const wchar_t * ReferenceString, unsigned CreationFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiCreateDeviceInterface)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, GUID &InterfaceClassGuid, const char * ReferenceString, unsigned CreationFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiCreateInterfaceDeviceA)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, GUID &InterfaceClassGuid, const char * ReferenceString, unsigned CreationFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiCreateInterfaceDeviceW)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, GUID &InterfaceClassGuid, const wchar_t * ReferenceString, unsigned CreationFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiCreateInterfaceDevice)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, GUID &InterfaceClassGuid, const char * ReferenceString, unsigned CreationFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiOpenDeviceInterfaceA)(void * DeviceInfoSet, const char * DevicePath, unsigned OpenFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiOpenDeviceInterfaceW)(void * DeviceInfoSet, const wchar_t * DevicePath, unsigned OpenFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiOpenDeviceInterface)(void * DeviceInfoSet, const char * DevicePath, unsigned OpenFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiOpenInterfaceDeviceA)(void * DeviceInfoSet, const char * DevicePath, unsigned OpenFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiOpenInterfaceDeviceW)(void * DeviceInfoSet, const wchar_t * DevicePath, unsigned OpenFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiOpenInterfaceDevice)(void * DeviceInfoSet, const char * DevicePath, unsigned OpenFlags, PSPDeviceInterfaceData DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiGetDeviceInterfaceAlias)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, GUID &AliasInterfaceClassGuid, SP_DEVICE_INTERFACE_DATA &AliasDeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiGetInterfaceDeviceAlias)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, GUID &AliasInterfaceClassGuid, SP_DEVICE_INTERFACE_DATA &AliasDeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiDeleteDeviceInterfaceData)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiDeleteInterfaceDeviceData)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiRemoveDeviceInterface)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiRemoveInterfaceDevice)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData);

typedef BOOL __stdcall (*TSetupDiGetDeviceInterfaceDetailA)(void * DeviceInfoSet, PSPDeviceInterfaceData DeviceInterfaceData, PSPDeviceInterfaceDetailDataA DeviceInterfaceDetailData, unsigned DeviceInterfaceDetailDataSize, unsigned &RequiredSize, PSPDevInfoData Device);

typedef BOOL __stdcall (*TSetupDiGetDeviceInterfaceDetailW)(void * DeviceInfoSet, PSPDeviceInterfaceData DeviceInterfaceData, PSPDeviceInterfaceDetailDataW DeviceInterfaceDetailData, unsigned DeviceInterfaceDetailDataSize, unsigned &RequiredSize, PSPDevInfoData Device);

typedef BOOL __stdcall (*TSetupDiGetDeviceInterfaceDetail)(void * DeviceInfoSet, PSPDeviceInterfaceData DeviceInterfaceData, PSPDeviceInterfaceDetailDataA DeviceInterfaceDetailData, unsigned DeviceInterfaceDetailDataSize, unsigned &RequiredSize, PSPDevInfoData Device);

typedef BOOL __stdcall (*TSetupDiGetInterfaceDeviceDetailA)(void * DeviceInfoSet, PSPDeviceInterfaceData DeviceInterfaceData, PSPDeviceInterfaceDetailDataA DeviceInterfaceDetailData, unsigned DeviceInterfaceDetailDataSize, PDWORD RequiredSize, PSPDevInfoData Device);

typedef BOOL __stdcall (*TSetupDiGetInterfaceDeviceDetailW)(void * DeviceInfoSet, PSPDeviceInterfaceData DeviceInterfaceData, PSPDeviceInterfaceDetailDataW DeviceInterfaceDetailData, unsigned DeviceInterfaceDetailDataSize, PDWORD RequiredSize, PSPDevInfoData Device);

typedef BOOL __stdcall (*TSetupDiGetInterfaceDeviceDetail)(void * DeviceInfoSet, PSPDeviceInterfaceData DeviceInterfaceData, PSPDeviceInterfaceDetailDataA DeviceInterfaceDetailData, unsigned DeviceInterfaceDetailDataSize, PDWORD RequiredSize, PSPDevInfoData Device);

typedef BOOL __stdcall (*TSetupDiInstallDeviceInterfaces)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiInstallInterfaceDevices)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiRegisterDeviceInfo)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Flags, TSPDetsigCmpProc CompareProc, void * CompareContext, PSPDevInfoData DupDeviceInfoData);

typedef BOOL __stdcall (*TSetupDiBuildDriverInfoList)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, unsigned DriverType);

typedef BOOL __stdcall (*TSetupDiCancelDriverInfoSearch)(void * DeviceInfoSet);

typedef BOOL __stdcall (*TSetupDiEnumDriverInfoA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, unsigned DriverType, unsigned MemberIndex, SP_DRVINFO_DATA_V2_A &DriverInfoData);

typedef BOOL __stdcall (*TSetupDiEnumDriverInfoW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, unsigned DriverType, unsigned MemberIndex, SP_DRVINFO_DATA_V2_W &DriverInfoData);

typedef BOOL __stdcall (*TSetupDiEnumDriverInfo)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, unsigned DriverType, unsigned MemberIndex, SP_DRVINFO_DATA_V2_A &DriverInfoData);

typedef BOOL __stdcall (*TSetupDiGetSelectedDriverA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData);

typedef BOOL __stdcall (*TSetupDiGetSelectedDriverW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_W &DriverInfoData);

typedef BOOL __stdcall (*TSetupDiGetSelectedDriver)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData);

typedef BOOL __stdcall (*TSetupDiSetSelectedDriverA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPDrvInfoDataV2A DriverInfoData);

typedef BOOL __stdcall (*TSetupDiSetSelectedDriverW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPDrvInfoDataV2W DriverInfoData);

typedef BOOL __stdcall (*TSetupDiSetSelectedDriver)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPDrvInfoDataV2A DriverInfoData);

typedef BOOL __stdcall (*TSetupDiGetDriverInfoDetailA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData, PSPDrvInfoDetailDataA DriverInfoDetailData, unsigned DriverInfoDetailDataSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetDriverInfoDetailW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_W &DriverInfoData, PSPDrvInfoDetailDataW DriverInfoDetailData, unsigned DriverInfoDetailDataSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetDriverInfoDetail)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData, PSPDrvInfoDetailDataA DriverInfoDetailData, unsigned DriverInfoDetailDataSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiDestroyDriverInfoList)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, unsigned DriverType);

typedef void * __stdcall (*TSetupDiGetClassDevsA)(System::PGUID ClassGuid, const char * Enumerator, HWND hwndParent, unsigned Flags);

typedef void * __stdcall (*TSetupDiGetClassDevsW)(System::PGUID ClassGuid, const wchar_t * Enumerator, HWND hwndParent, unsigned Flags);

typedef void * __stdcall (*TSetupDiGetClassDevs)(System::PGUID ClassGuid, const char * Enumerator, HWND hwndParent, unsigned Flags);

typedef void * __stdcall (*TSetupDiGetClassDevsExA)(System::PGUID ClassGuid, const char * Enumerator, HWND hwndParent, unsigned Flags, void * DeviceInfoSet, const char * MachineName, void * Reserved);

typedef void * __stdcall (*TSetupDiGetClassDevsExW)(System::PGUID ClassGuid, const wchar_t * Enumerator, HWND hwndParent, unsigned Flags, void * DeviceInfoSet, const wchar_t * MachineName, void * Reserved);

typedef void * __stdcall (*TSetupDiGetClassDevsEx)(System::PGUID ClassGuid, const char * Enumerator, HWND hwndParent, unsigned Flags, void * DeviceInfoSet, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetINFClassA)(const char * InfName, GUID &ClassGuid, char * ClassName, unsigned ClassNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetINFClassW)(const wchar_t * InfName, GUID &ClassGuid, wchar_t * ClassName, unsigned ClassNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetINFClass)(const char * InfName, GUID &ClassGuid, char * ClassName, unsigned ClassNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiBuildClassInfoList)(unsigned Flags, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize);

typedef BOOL __stdcall (*TSetupDiBuildClassInfoListExA)(unsigned Flags, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiBuildClassInfoListExW)(unsigned Flags, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize, const wchar_t * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiBuildClassInfoListEx)(unsigned Flags, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetClassDescriptionA)(GUID &ClassGuid, char * ClassDescription, unsigned ClassDescriptionSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetClassDescriptionW)(GUID &ClassGuid, wchar_t * ClassDescription, unsigned ClassDescriptionSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetClassDescription)(GUID &ClassGuid, char * ClassDescription, unsigned ClassDescriptionSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetClassDescriptionExA)(GUID &ClassGuid, char * ClassDescription, unsigned ClassDescriptionSize, PDWORD RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetClassDescriptionExW)(GUID &ClassGuid, wchar_t * ClassDescription, unsigned ClassDescriptionSize, PDWORD RequiredSize, const wchar_t * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetClassDescriptionEx)(GUID &ClassGuid, char * ClassDescription, unsigned ClassDescriptionSize, PDWORD RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiCallClassInstaller)(unsigned InstallFunction, void * DeviceInfoSet, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiSelectDevice)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiSelectBestCompatDrv)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiInstallDevice)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiInstallDriverFiles)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiRegisterCoDeviceInstallers)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiRemoveDevice)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiUnremoveDevice)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiMoveDuplicateDevice)(void * DeviceInfoSet, SP_DEVINFO_DATA &DestinationDeviceInfoData);

typedef BOOL __stdcall (*TSetupDiChangeState)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiInstallClassA)(HWND hwndParent, const char * InfFileName, unsigned Flags, void * FileQueue);

typedef BOOL __stdcall (*TSetupDiInstallClassW)(HWND hwndParent, const wchar_t * InfFileName, unsigned Flags, void * FileQueue);

typedef BOOL __stdcall (*TSetupDiInstallClass)(HWND hwndParent, const char * InfFileName, unsigned Flags, void * FileQueue);

typedef BOOL __stdcall (*TSetupDiInstallClassExA)(HWND hwndParent, const char * InfFileName, unsigned Flags, void * FileQueue, System::PGUID InterfaceClassGuid, void * Reserved1, void * Reserved2);

typedef BOOL __stdcall (*TSetupDiInstallClassExW)(HWND hwndParent, const wchar_t * InfFileName, unsigned Flags, void * FileQueue, System::PGUID InterfaceClassGuid, void * Reserved1, void * Reserved2);

typedef BOOL __stdcall (*TSetupDiInstallClassEx)(HWND hwndParent, const char * InfFileName, unsigned Flags, void * FileQueue, System::PGUID InterfaceClassGuid, void * Reserved1, void * Reserved2);

typedef HKEY __stdcall (*TSetupDiOpenClassRegKey)(System::PGUID ClassGuid, unsigned samDesired);

typedef HKEY __stdcall (*TSetupDiOpenClassRegKeyExA)(System::PGUID ClassGuid, unsigned samDesired, unsigned Flags, const char * MachineName, void * Reserved);

typedef HKEY __stdcall (*TSetupDiOpenClassRegKeyExW)(System::PGUID ClassGuid, unsigned samDesired, unsigned Flags, const wchar_t * MachineName, void * Reserved);

typedef HKEY __stdcall (*TSetupDiOpenClassRegKeyEx)(System::PGUID ClassGuid, unsigned samDesired, unsigned Flags, const char * MachineName, void * Reserved);

typedef HKEY __stdcall (*TSetupDiCreateDeviceInterfaceRegKeyA)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired, void * InfHandle, const char * InfSectionName);

typedef HKEY __stdcall (*TSetupDiCreateDeviceInterfaceRegKeyW)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired, void * InfHandle, const wchar_t * InfSectionName);

typedef HKEY __stdcall (*TSetupDiCreateDeviceInterfaceRegKey)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired, void * InfHandle, const char * InfSectionName);

typedef HKEY __stdcall (*TSetupDiCreateInterfaceDeviceRegKeyA)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired, void * InfHandle, const char * InfSectionName);

typedef HKEY __stdcall (*TSetupDiCreateInterfaceDeviceRegKeyW)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired, void * InfHandle, const wchar_t * InfSectionName);

typedef HKEY __stdcall (*TSetupDiCreateInterfaceDeviceRegKey)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired, void * InfHandle, const char * InfSectionName);

typedef HKEY __stdcall (*TSetupDiOpenDeviceInterfaceRegKey)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired);

typedef HKEY __stdcall (*TSetupDiOpenInterfaceDeviceRegKey)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved, unsigned samDesired);

typedef BOOL __stdcall (*TSetupDiDeleteDeviceInterfaceRegKey)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved);

typedef BOOL __stdcall (*TSetupDiDeleteInterfaceDeviceRegKey)(void * DeviceInfoSet, SP_DEVICE_INTERFACE_DATA &DeviceInterfaceData, unsigned Reserved);

typedef HKEY __stdcall (*TSetupDiCreateDevRegKeyA)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Scope, unsigned HwProfile, unsigned KeyType, void * InfHandle, const char * InfSectionName);

typedef HKEY __stdcall (*TSetupDiCreateDevRegKeyW)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Scope, unsigned HwProfile, unsigned KeyType, void * InfHandle, const wchar_t * InfSectionName);

typedef HKEY __stdcall (*TSetupDiCreateDevRegKey)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Scope, unsigned HwProfile, unsigned KeyType, void * InfHandle, const char * InfSectionName);

typedef HKEY __stdcall (*TSetupDiOpenDevRegKey)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Scope, unsigned HwProfile, unsigned KeyType, unsigned samDesired);

typedef BOOL __stdcall (*TSetupDiDeleteDevRegKey)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Scope, unsigned HwProfile, unsigned KeyType);

typedef BOOL __stdcall (*TSetupDiGetHwProfileList)(PDWORD HwProfileList, unsigned HwProfileListSize, unsigned &RequiredSize, PDWORD CurrentlyActiveIndex);

typedef BOOL __stdcall (*TSetupDiGetHwProfileListExA)(PDWORD HwProfileList, unsigned HwProfileListSize, unsigned &RequiredSize, PDWORD CurrentlyActiveIndex, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetHwProfileListExW)(PDWORD HwProfileList, unsigned HwProfileListSize, unsigned &RequiredSize, PDWORD CurrentlyActiveIndex, const wchar_t * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetHwProfileListEx)(PDWORD HwProfileList, unsigned HwProfileListSize, unsigned &RequiredSize, PDWORD CurrentlyActiveIndex, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetDeviceRegistryPropertyA)(void * DeviceInfoSet, const SP_DEVINFO_DATA &DeviceInfoData, unsigned Property_, unsigned &PropertyRegDataType, System::PByte PropertyBuffer, unsigned PropertyBufferSize, unsigned &RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetDeviceRegistryPropertyW)(void * DeviceInfoSet, const SP_DEVINFO_DATA &DeviceInfoData, unsigned Property_, unsigned &PropertyRegDataType, System::PByte PropertyBuffer, unsigned PropertyBufferSize, unsigned &RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetDeviceRegistryProperty)(void * DeviceInfoSet, const SP_DEVINFO_DATA &DeviceInfoData, unsigned Property_, unsigned &PropertyRegDataType, System::PByte PropertyBuffer, unsigned PropertyBufferSize, unsigned &RequiredSize);

typedef BOOL __stdcall (*TSetupDiSetDeviceRegistryPropertyA)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Property_, const System::PByte PropertyBuffer, unsigned PropertyBufferSize);

typedef BOOL __stdcall (*TSetupDiSetDeviceRegistryPropertyW)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Property_, const System::PByte PropertyBuffer, unsigned PropertyBufferSize);

typedef BOOL __stdcall (*TSetupDiSetDeviceRegistryProperty)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData, unsigned Property_, const System::PByte PropertyBuffer, unsigned PropertyBufferSize);

typedef BOOL __stdcall (*TSetupDiGetDeviceInstallParamsA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DEVINSTALL_PARAMS_A &DeviceInstallParams);

typedef BOOL __stdcall (*TSetupDiGetDeviceInstallParamsW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DEVINSTALL_PARAMS_W &DeviceInstallParams);

typedef BOOL __stdcall (*TSetupDiGetDeviceInstallParams)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DEVINSTALL_PARAMS_A &DeviceInstallParams);

typedef BOOL __stdcall (*TSetupDiGetClassInstallParamsA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPClassInstallHeader ClassInstallParams, unsigned ClassInstallParamsSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetClassInstallParamsW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPClassInstallHeader ClassInstallParams, unsigned ClassInstallParamsSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetClassInstallParams)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPClassInstallHeader ClassInstallParams, unsigned ClassInstallParamsSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiSetDeviceInstallParamsA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DEVINSTALL_PARAMS_A &DeviceInstallParams);

typedef BOOL __stdcall (*TSetupDiSetDeviceInstallParamsW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DEVINSTALL_PARAMS_W &DeviceInstallParams);

typedef BOOL __stdcall (*TSetupDiSetDeviceInstallParams)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DEVINSTALL_PARAMS_A &DeviceInstallParams);

typedef BOOL __stdcall (*TSetupDiSetClassInstallParamsA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPClassInstallHeader ClassInstallParams, unsigned ClassInstallParamsSize);

typedef BOOL __stdcall (*TSetupDiSetClassInstallParamsW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPClassInstallHeader ClassInstallParams, unsigned ClassInstallParamsSize);

typedef BOOL __stdcall (*TSetupDiSetClassInstallParams)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, PSPClassInstallHeader ClassInstallParams, unsigned ClassInstallParamsSize);

typedef BOOL __stdcall (*TSetupDiGetDriverInstallParamsA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData, SP_DRVINSTALL_PARAMS &DriverInstallParams);

typedef BOOL __stdcall (*TSetupDiGetDriverInstallParamsW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_W &DriverInfoData, SP_DRVINSTALL_PARAMS &DriverInstallParams);

typedef BOOL __stdcall (*TSetupDiGetDriverInstallParams)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData, SP_DRVINSTALL_PARAMS &DriverInstallParams);

typedef BOOL __stdcall (*TSetupDiSetDriverInstallParamsA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData, SP_DRVINSTALL_PARAMS &DriverInstallParams);

typedef BOOL __stdcall (*TSetupDiSetDriverInstallParamsW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_W &DriverInfoData, SP_DRVINSTALL_PARAMS &DriverInstallParams);

typedef BOOL __stdcall (*TSetupDiSetDriverInstallParams)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_DRVINFO_DATA_V2_A &DriverInfoData, SP_DRVINSTALL_PARAMS &DriverInstallParams);

typedef BOOL __stdcall (*TSetupDiLoadClassIcon)(GUID &ClassGuid, PHICON LargeIcon, PINT MiniIconIndex);

typedef int __stdcall (*TSetupDiDrawMiniIcon)(HDC hdc, const Types::TRect rc, int MiniIconIndex, unsigned Flags);

typedef BOOL __stdcall (*TSetupDiGetClassBitmapIndex)(System::PGUID ClassGuid, int &MiniIconIndex);

typedef BOOL __stdcall (*TSetupDiGetClassImageList)(SP_CLASSIMAGELIST_DATA &ClassImageListData);

typedef BOOL __stdcall (*TSetupDiGetClassImageListExA)(SP_CLASSIMAGELIST_DATA &ClassImageListData, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetClassImageListExW)(SP_CLASSIMAGELIST_DATA &ClassImageListData, const wchar_t * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetClassImageListEx)(SP_CLASSIMAGELIST_DATA &ClassImageListData, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetClassImageIndex)(SP_CLASSIMAGELIST_DATA &ClassImageListData, GUID &ClassGuid, int &ImageIndex);

typedef BOOL __stdcall (*TSetupDiDestroyClassImageList)(SP_CLASSIMAGELIST_DATA &ClassImageListData);

typedef BOOL __stdcall (*TSetupDiGetClassDevPropertySheetsA)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, _PROPSHEETHEADERA &PropertySheetHeader, unsigned PropertySheetHeaderPageListSize, PDWORD RequiredSize, unsigned PropertySheetType);

typedef BOOL __stdcall (*TSetupDiGetClassDevPropertySheetsW)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, _PROPSHEETHEADERW &PropertySheetHeader, unsigned PropertySheetHeaderPageListSize, PDWORD RequiredSize, unsigned PropertySheetType);

typedef BOOL __stdcall (*TSetupDiGetClassDevPropertySheets)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, _PROPSHEETHEADERA &PropertySheetHeader, unsigned PropertySheetHeaderPageListSize, PDWORD RequiredSize, unsigned PropertySheetType);

typedef BOOL __stdcall (*TSetupDiAskForOEMDisk)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiSelectOEMDrv)(HWND hwndParent, void * DeviceInfoSet, PSPDevInfoData DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiClassNameFromGuidA)(GUID &ClassGuid, char * ClassName, unsigned ClassNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiClassNameFromGuidW)(GUID &ClassGuid, wchar_t * ClassName, unsigned ClassNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiClassNameFromGuid)(GUID &ClassGuid, char * ClassName, unsigned ClassNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiClassNameFromGuidExA)(GUID &ClassGuid, char * ClassName, unsigned ClassNameSize, PDWORD RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiClassNameFromGuidExW)(GUID &ClassGuid, wchar_t * ClassName, unsigned ClassNameSize, PDWORD RequiredSize, const wchar_t * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiClassNameFromGuidEx)(GUID &ClassGuid, char * ClassName, unsigned ClassNameSize, PDWORD RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiClassGuidsFromNameA)(const char * ClassName, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize);

typedef BOOL __stdcall (*TSetupDiClassGuidsFromNameW)(const wchar_t * ClassName, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize);

typedef BOOL __stdcall (*TSetupDiClassGuidsFromName)(const char * ClassName, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize);

typedef BOOL __stdcall (*TSetupDiClassGuidsFromNameExA)(const char * ClassName, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiClassGuidsFromNameExW)(const wchar_t * ClassName, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize, const wchar_t * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiClassGuidsFromNameEx)(const char * ClassName, System::PGUID ClassGuidList, unsigned ClassGuidListSize, unsigned &RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetHwProfileFriendlyNameA)(unsigned HwProfile, char * FriendlyName, unsigned FriendlyNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetHwProfileFriendlyNameW)(unsigned HwProfile, wchar_t * FriendlyName, unsigned FriendlyNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetHwProfileFriendlyName)(unsigned HwProfile, char * FriendlyName, unsigned FriendlyNameSize, PDWORD RequiredSize);

typedef BOOL __stdcall (*TSetupDiGetHwProfileFriendlyNameExA)(unsigned HwProfile, char * FriendlyName, unsigned FriendlyNameSize, PDWORD RequiredSize, const char * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetHwProfileFriendlyNameExW)(unsigned HwProfile, wchar_t * FriendlyName, unsigned FriendlyNameSize, PDWORD RequiredSize, const wchar_t * MachineName, void * Reserved);

typedef BOOL __stdcall (*TSetupDiGetHwProfileFriendlyNameEx)(unsigned HwProfile, char * FriendlyName, unsigned FriendlyNameSize, PDWORD RequiredSize, const char * MachineName, void * Reserved);

typedef void * __stdcall (*TSetupDiGetWizardPage)(void * DeviceInfoSet, PSPDevInfoData DeviceInfoData, SP_INSTALLWIZARD_DATA &InstallWizardData, unsigned PageType, unsigned Flags);

typedef BOOL __stdcall (*TSetupDiGetSelectedDevice)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiSetSelectedDevice)(void * DeviceInfoSet, SP_DEVINFO_DATA &DeviceInfoData);

typedef BOOL __stdcall (*TSetupDiGetActualSectionToInstallA)(void * InfHandle, const char * InfSectionName, char * InfSectionWithExt, unsigned InfSectionWithExtSize, PDWORD RequiredSize, PPASTR Extension);

typedef BOOL __stdcall (*TSetupDiGetActualSectionToInstallW)(void * InfHandle, const wchar_t * InfSectionName, wchar_t * InfSectionWithExt, unsigned InfSectionWithExtSize, PDWORD RequiredSize, PPWSTR Extension);

typedef BOOL __stdcall (*TSetupDiGetActualSectionToInstall)(void * InfHandle, const char * InfSectionName, char * InfSectionWithExt, unsigned InfSectionWithExtSize, PDWORD RequiredSize, PPSTR Extension);

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TSetupGetInfInformationA SetupGetInfInformationA;
extern PACKAGE TSetupGetInfInformationW SetupGetInfInformationW;
extern PACKAGE TSetupGetInfInformationA SetupGetInfInformation;
extern PACKAGE TSetupQueryInfFileInformationA SetupQueryInfFileInformationA;
extern PACKAGE TSetupQueryInfFileInformationW SetupQueryInfFileInformationW;
extern PACKAGE TSetupQueryInfFileInformationA SetupQueryInfFileInformation;
extern PACKAGE TSetupQueryInfVersionInformationA SetupQueryInfVersionInformationA;
extern PACKAGE TSetupQueryInfVersionInformationW SetupQueryInfVersionInformationW;
extern PACKAGE TSetupQueryInfVersionInformationA SetupQueryInfVersionInformation;
extern PACKAGE TSetupGetInfFileListA SetupGetInfFileListA;
extern PACKAGE TSetupGetInfFileListW SetupGetInfFileListW;
extern PACKAGE TSetupGetInfFileListA SetupGetInfFileList;
extern PACKAGE TSetupOpenInfFileA SetupOpenInfFileA;
extern PACKAGE TSetupOpenInfFileW SetupOpenInfFileW;
extern PACKAGE TSetupOpenInfFileA SetupOpenInfFile;
extern PACKAGE TSetupOpenMasterInf SetupOpenMasterInf;
extern PACKAGE TSetupOpenAppendInfFileA SetupOpenAppendInfFileA;
extern PACKAGE TSetupOpenAppendInfFileW SetupOpenAppendInfFileW;
extern PACKAGE TSetupOpenAppendInfFileA SetupOpenAppendInfFile;
extern PACKAGE TSetupCloseInfFile SetupCloseInfFile;
extern PACKAGE TSetupFindFirstLineA SetupFindFirstLineA;
extern PACKAGE TSetupFindFirstLineW SetupFindFirstLineW;
extern PACKAGE TSetupFindFirstLineA SetupFindFirstLine;
extern PACKAGE TSetupFindNextLine SetupFindNextLine;
extern PACKAGE TSetupFindNextMatchLineA SetupFindNextMatchLineA;
extern PACKAGE TSetupFindNextMatchLineW SetupFindNextMatchLineW;
extern PACKAGE TSetupFindNextMatchLineA SetupFindNextMatchLine;
extern PACKAGE TSetupGetLineByIndexA SetupGetLineByIndexA;
extern PACKAGE TSetupGetLineByIndexW SetupGetLineByIndexW;
extern PACKAGE TSetupGetLineByIndexA SetupGetLineByIndex;
extern PACKAGE TSetupGetLineCountA SetupGetLineCountA;
extern PACKAGE TSetupGetLineCountW SetupGetLineCountW;
extern PACKAGE TSetupGetLineCountA SetupGetLineCount;
extern PACKAGE TSetupGetLineTextA SetupGetLineTextA;
extern PACKAGE TSetupGetLineTextW SetupGetLineTextW;
extern PACKAGE TSetupGetLineTextA SetupGetLineText;
extern PACKAGE TSetupGetFieldCount SetupGetFieldCount;
extern PACKAGE TSetupGetStringFieldA SetupGetStringFieldA;
extern PACKAGE TSetupGetStringFieldW SetupGetStringFieldW;
extern PACKAGE TSetupGetStringFieldA SetupGetStringField;
extern PACKAGE TSetupGetIntField SetupGetIntField;
extern PACKAGE TSetupGetMultiSzFieldA SetupGetMultiSzFieldA;
extern PACKAGE TSetupGetMultiSzFieldW SetupGetMultiSzFieldW;
extern PACKAGE TSetupGetMultiSzFieldA SetupGetMultiSzField;
extern PACKAGE TSetupGetBinaryField SetupGetBinaryField;
extern PACKAGE TSetupGetFileCompressionInfoA SetupGetFileCompressionInfoA;
extern PACKAGE TSetupGetFileCompressionInfoW SetupGetFileCompressionInfoW;
extern PACKAGE TSetupGetFileCompressionInfoA SetupGetFileCompressionInfo;
extern PACKAGE TSetupDecompressOrCopyFileA SetupDecompressOrCopyFileA;
extern PACKAGE TSetupDecompressOrCopyFileW SetupDecompressOrCopyFileW;
extern PACKAGE TSetupDecompressOrCopyFileA SetupDecompressOrCopyFile;
extern PACKAGE TSetupGetSourceFileLocationA SetupGetSourceFileLocationA;
extern PACKAGE TSetupGetSourceFileLocationW SetupGetSourceFileLocationW;
extern PACKAGE TSetupGetSourceFileLocationA SetupGetSourceFileLocation;
extern PACKAGE TSetupGetSourceFileSizeA SetupGetSourceFileSizeA;
extern PACKAGE TSetupGetSourceFileSizeW SetupGetSourceFileSizeW;
extern PACKAGE TSetupGetSourceFileSizeA SetupGetSourceFileSize;
extern PACKAGE TSetupGetTargetPathA SetupGetTargetPathA;
extern PACKAGE TSetupGetTargetPathW SetupGetTargetPathW;
extern PACKAGE TSetupGetTargetPathA SetupGetTargetPath;
extern PACKAGE TSetupSetSourceListA SetupSetSourceListA;
extern PACKAGE TSetupSetSourceListW SetupSetSourceListW;
extern PACKAGE TSetupSetSourceList SetupSetSourceList;
extern PACKAGE TSetupCancelTemporarySourceList SetupCancelTemporarySourceList;
extern PACKAGE TSetupAddToSourceListA SetupAddToSourceListA;
extern PACKAGE TSetupAddToSourceListW SetupAddToSourceListW;
extern PACKAGE TSetupAddToSourceListA SetupAddToSourceList;
extern PACKAGE TSetupRemoveFromSourceListA SetupRemoveFromSourceListA;
extern PACKAGE TSetupRemoveFromSourceListW SetupRemoveFromSourceListW;
extern PACKAGE TSetupRemoveFromSourceListA SetupRemoveFromSourceList;
extern PACKAGE TSetupQuerySourceListA SetupQuerySourceListA;
extern PACKAGE TSetupQuerySourceListW SetupQuerySourceListW;
extern PACKAGE TSetupQuerySourceList SetupQuerySourceList;
extern PACKAGE TSetupFreeSourceListA SetupFreeSourceListA;
extern PACKAGE TSetupFreeSourceListW SetupFreeSourceListW;
extern PACKAGE TSetupFreeSourceList SetupFreeSourceList;
extern PACKAGE TSetupPromptForDiskA SetupPromptForDiskA;
extern PACKAGE TSetupPromptForDiskW SetupPromptForDiskW;
extern PACKAGE TSetupPromptForDiskA SetupPromptForDisk;
extern PACKAGE TSetupCopyErrorA SetupCopyErrorA;
extern PACKAGE TSetupCopyErrorW SetupCopyErrorW;
extern PACKAGE TSetupCopyErrorA SetupCopyError;
extern PACKAGE TSetupRenameErrorA SetupRenameErrorA;
extern PACKAGE TSetupRenameErrorW SetupRenameErrorW;
extern PACKAGE TSetupRenameErrorA SetupRenameError;
extern PACKAGE TSetupDeleteErrorA SetupDeleteErrorA;
extern PACKAGE TSetupDeleteErrorW SetupDeleteErrorW;
extern PACKAGE TSetupDeleteErrorA SetupDeleteError;
extern PACKAGE TSetupSetDirectoryIdA SetupSetDirectoryIdA;
extern PACKAGE TSetupSetDirectoryIdW SetupSetDirectoryIdW;
extern PACKAGE TSetupSetDirectoryIdA SetupSetDirectoryId;
extern PACKAGE TSetupSetDirectoryIdExA SetupSetDirectoryIdExA;
extern PACKAGE TSetupSetDirectoryIdExW SetupSetDirectoryIdExW;
extern PACKAGE TSetupSetDirectoryIdExA SetupSetDirectoryIdEx;
extern PACKAGE TSetupGetSourceInfoA SetupGetSourceInfoA;
extern PACKAGE TSetupGetSourceInfoW SetupGetSourceInfoW;
extern PACKAGE TSetupGetSourceInfoA SetupGetSourceInfo;
extern PACKAGE TSetupInstallFileA SetupInstallFileA;
extern PACKAGE TSetupInstallFileW SetupInstallFileW;
extern PACKAGE TSetupInstallFileA SetupInstallFile;
extern PACKAGE TSetupInstallFileExA SetupInstallFileExA;
extern PACKAGE TSetupInstallFileExW SetupInstallFileExW;
extern PACKAGE TSetupInstallFileExA SetupInstallFileEx;
extern PACKAGE TSetupOpenFileQueue SetupOpenFileQueue;
extern PACKAGE TSetupCloseFileQueue SetupCloseFileQueue;
extern PACKAGE TSetupSetPlatformPathOverrideA SetupSetPlatformPathOverrideA;
extern PACKAGE TSetupSetPlatformPathOverrideW SetupSetPlatformPathOverrideW;
extern PACKAGE TSetupSetPlatformPathOverrideA SetupSetPlatformPathOverride;
extern PACKAGE TSetupQueueCopyA SetupQueueCopyA;
extern PACKAGE TSetupQueueCopyW SetupQueueCopyW;
extern PACKAGE TSetupQueueCopyA SetupQueueCopy;
extern PACKAGE TSetupQueueDefaultCopyA SetupQueueDefaultCopyA;
extern PACKAGE TSetupQueueDefaultCopyW SetupQueueDefaultCopyW;
extern PACKAGE TSetupQueueDefaultCopyA SetupQueueDefaultCopy;
extern PACKAGE TSetupQueueCopySectionA SetupQueueCopySectionA;
extern PACKAGE TSetupQueueCopySectionW SetupQueueCopySectionW;
extern PACKAGE TSetupQueueCopySectionA SetupQueueCopySection;
extern PACKAGE TSetupQueueDeleteA SetupQueueDeleteA;
extern PACKAGE TSetupQueueDeleteW SetupQueueDeleteW;
extern PACKAGE TSetupQueueDeleteA SetupQueueDelete;
extern PACKAGE TSetupQueueDeleteSectionA SetupQueueDeleteSectionA;
extern PACKAGE TSetupQueueDeleteSectionW SetupQueueDeleteSectionW;
extern PACKAGE TSetupQueueDeleteSectionA SetupQueueDeleteSection;
extern PACKAGE TSetupQueueRenameA SetupQueueRenameA;
extern PACKAGE TSetupQueueRenameW SetupQueueRenameW;
extern PACKAGE TSetupQueueRenameA SetupQueueRename;
extern PACKAGE TSetupQueueRenameSectionA SetupQueueRenameSectionA;
extern PACKAGE TSetupQueueRenameSectionW SetupQueueRenameSectionW;
extern PACKAGE TSetupQueueRenameSectionA SetupQueueRenameSection;
extern PACKAGE TSetupCommitFileQueueA SetupCommitFileQueueA;
extern PACKAGE TSetupCommitFileQueueW SetupCommitFileQueueW;
extern PACKAGE TSetupCommitFileQueueA SetupCommitFileQueue;
extern PACKAGE TSetupScanFileQueueA SetupScanFileQueueA;
extern PACKAGE TSetupScanFileQueueW SetupScanFileQueueW;
extern PACKAGE TSetupScanFileQueueA SetupScanFileQueue;
extern PACKAGE TSetupCopyOEMInfA SetupCopyOEMInfA;
extern PACKAGE TSetupCopyOEMInfW SetupCopyOEMInfW;
extern PACKAGE TSetupCopyOEMInf SetupCopyOEMInf;
extern PACKAGE TSetupCreateDiskSpaceListA SetupCreateDiskSpaceListA;
extern PACKAGE TSetupCreateDiskSpaceListW SetupCreateDiskSpaceListW;
extern PACKAGE TSetupCreateDiskSpaceListA SetupCreateDiskSpaceList;
extern PACKAGE TSetupDuplicateDiskSpaceListA SetupDuplicateDiskSpaceListA;
extern PACKAGE TSetupDuplicateDiskSpaceListW SetupDuplicateDiskSpaceListW;
extern PACKAGE TSetupDuplicateDiskSpaceListA SetupDuplicateDiskSpaceList;
extern PACKAGE TSetupDestroyDiskSpaceList SetupDestroyDiskSpaceList;
extern PACKAGE TSetupQueryDrivesInDiskSpaceListA SetupQueryDrivesInDiskSpaceListA;
extern PACKAGE TSetupQueryDrivesInDiskSpaceListW SetupQueryDrivesInDiskSpaceListW;
extern PACKAGE TSetupQueryDrivesInDiskSpaceListA SetupQueryDrivesInDiskSpaceList;
extern PACKAGE TSetupQuerySpaceRequiredOnDriveA SetupQuerySpaceRequiredOnDriveA;
extern PACKAGE TSetupQuerySpaceRequiredOnDriveW SetupQuerySpaceRequiredOnDriveW;
extern PACKAGE TSetupQuerySpaceRequiredOnDriveA SetupQuerySpaceRequiredOnDrive;
extern PACKAGE TSetupAdjustDiskSpaceListA SetupAdjustDiskSpaceListA;
extern PACKAGE TSetupAdjustDiskSpaceListW SetupAdjustDiskSpaceListW;
extern PACKAGE TSetupAdjustDiskSpaceListA SetupAdjustDiskSpaceList;
extern PACKAGE TSetupAddToDiskSpaceListA SetupAddToDiskSpaceListA;
extern PACKAGE TSetupAddToDiskSpaceListW SetupAddToDiskSpaceListW;
extern PACKAGE TSetupAddToDiskSpaceListA SetupAddToDiskSpaceList;
extern PACKAGE TSetupAddSectionToDiskSpaceListA SetupAddSectionToDiskSpaceListA;
extern PACKAGE TSetupAddSectionToDiskSpaceListW SetupAddSectionToDiskSpaceListW;
extern PACKAGE TSetupAddSectionToDiskSpaceListA SetupAddSectionToDiskSpaceList;
extern PACKAGE TSetupAddInstallSectionToDiskSpaceListA SetupAddInstallSectionToDiskSpaceListA;
extern PACKAGE TSetupAddInstallSectionToDiskSpaceListW SetupAddInstallSectionToDiskSpaceListW;
extern PACKAGE TSetupAddInstallSectionToDiskSpaceListA SetupAddInstallSectionToDiskSpaceList;
extern PACKAGE TSetupRemoveFromDiskSpaceListA SetupRemoveFromDiskSpaceListA;
extern PACKAGE TSetupRemoveFromDiskSpaceListW SetupRemoveFromDiskSpaceListW;
extern PACKAGE TSetupRemoveFromDiskSpaceListA SetupRemoveFromDiskSpaceList;
extern PACKAGE TSetupRemoveSectionFromDiskSpaceListA SetupRemoveSectionFromDiskSpaceListA;
extern PACKAGE TSetupRemoveSectionFromDiskSpaceListW SetupRemoveSectionFromDiskSpaceListW;
extern PACKAGE TSetupRemoveSectionFromDiskSpaceListA SetupRemoveSectionFromDiskSpaceList;
extern PACKAGE TSetupRemoveInstallSectionFromDiskSpaceListA SetupRemoveInstallSectionFromDiskSpaceListA;
extern PACKAGE TSetupRemoveInstallSectionFromDiskSpaceListW SetupRemoveInstallSectionFromDiskSpaceListW;
extern PACKAGE TSetupRemoveInstallSectionFromDiskSpaceListA SetupRemoveInstallSectionFromDiskSpaceList;
extern PACKAGE TSetupIterateCabinetA SetupIterateCabinetA;
extern PACKAGE TSetupIterateCabinetW SetupIterateCabinetW;
extern PACKAGE TSetupIterateCabinetA SetupIterateCabinet;
extern PACKAGE TSetupPromptReboot SetupPromptReboot;
extern PACKAGE TSetupInitDefaultQueueCallback SetupInitDefaultQueueCallback;
extern PACKAGE TSetupInitDefaultQueueCallbackEx SetupInitDefaultQueueCallbackEx;
extern PACKAGE TSetupTermDefaultQueueCallback SetupTermDefaultQueueCallback;
extern PACKAGE TSetupDefaultQueueCallbackA SetupDefaultQueueCallbackA;
extern PACKAGE TSetupDefaultQueueCallbackW SetupDefaultQueueCallbackW;
extern PACKAGE TSetupDefaultQueueCallbackA SetupDefaultQueueCallback;
extern PACKAGE TSetupInstallFromInfSectionA SetupInstallFromInfSectionA;
extern PACKAGE TSetupInstallFromInfSectionW SetupInstallFromInfSectionW;
extern PACKAGE TSetupInstallFromInfSectionA SetupInstallFromInfSection;
extern PACKAGE TSetupInstallFilesFromInfSectionA SetupInstallFilesFromInfSectionA;
extern PACKAGE TSetupInstallFilesFromInfSectionW SetupInstallFilesFromInfSectionW;
extern PACKAGE TSetupInstallFilesFromInfSectionA SetupInstallFilesFromInfSection;
extern PACKAGE TSetupInstallServicesFromInfSectionA SetupInstallServicesFromInfSectionA;
extern PACKAGE TSetupInstallServicesFromInfSectionW SetupInstallServicesFromInfSectionW;
extern PACKAGE TSetupInstallServicesFromInfSectionA SetupInstallServicesFromInfSection;
extern PACKAGE TSetupInstallServicesFromInfSectionExA SetupInstallServicesFromInfSectionExA;
extern PACKAGE TSetupInstallServicesFromInfSectionExW SetupInstallServicesFromInfSectionExW;
extern PACKAGE TSetupInstallServicesFromInfSectionExA SetupInstallServicesFromInfSectionEx;
extern PACKAGE TSetupInitializeFileLogA SetupInitializeFileLogA;
extern PACKAGE TSetupInitializeFileLogW SetupInitializeFileLogW;
extern PACKAGE TSetupInitializeFileLogA SetupInitializeFileLog;
extern PACKAGE TSetupTerminateFileLog SetupTerminateFileLog;
extern PACKAGE TSetupLogFileA SetupLogFileA;
extern PACKAGE TSetupLogFileW SetupLogFileW;
extern PACKAGE TSetupLogFileA SetupLogFile;
extern PACKAGE TSetupRemoveFileLogEntryA SetupRemoveFileLogEntryA;
extern PACKAGE TSetupRemoveFileLogEntryW SetupRemoveFileLogEntryW;
extern PACKAGE TSetupRemoveFileLogEntryA SetupRemoveFileLogEntry;
extern PACKAGE TSetupQueryFileLogA SetupQueryFileLogA;
extern PACKAGE TSetupQueryFileLogW SetupQueryFileLogW;
extern PACKAGE TSetupQueryFileLogA SetupQueryFileLog;
extern PACKAGE TSetupOpenLog SetupOpenLog;
extern PACKAGE TSetupLogErrorA SetupLogErrorA;
extern PACKAGE TSetupLogErrorW SetupLogErrorW;
extern PACKAGE TSetupLogErrorA SetupLogError;
extern PACKAGE TSetupCloseLog SetupCloseLog;
extern PACKAGE TSetupDiCreateDeviceInfoList SetupDiCreateDeviceInfoList;
extern PACKAGE TSetupDiCreateDeviceInfoListExA SetupDiCreateDeviceInfoListExA;
extern PACKAGE TSetupDiCreateDeviceInfoListExW SetupDiCreateDeviceInfoListExW;
extern PACKAGE TSetupDiCreateDeviceInfoListExA SetupDiCreateDeviceInfoListEx;
extern PACKAGE TSetupDiGetDeviceInfoListClass SetupDiGetDeviceInfoListClass;
extern PACKAGE TSetupDiGetDeviceInfoListDetailA SetupDiGetDeviceInfoListDetailA;
extern PACKAGE TSetupDiGetDeviceInfoListDetailW SetupDiGetDeviceInfoListDetailW;
extern PACKAGE TSetupDiGetDeviceInfoListDetailA SetupDiGetDeviceInfoListDetail;
extern PACKAGE TSetupDiCreateDeviceInfoA SetupDiCreateDeviceInfoA;
extern PACKAGE TSetupDiCreateDeviceInfoW SetupDiCreateDeviceInfoW;
extern PACKAGE TSetupDiCreateDeviceInfoA SetupDiCreateDeviceInfo;
extern PACKAGE TSetupDiOpenDeviceInfoA SetupDiOpenDeviceInfoA;
extern PACKAGE TSetupDiOpenDeviceInfoW SetupDiOpenDeviceInfoW;
extern PACKAGE TSetupDiOpenDeviceInfoA SetupDiOpenDeviceInfo;
extern PACKAGE TSetupDiGetDeviceInstanceIdA SetupDiGetDeviceInstanceIdA;
extern PACKAGE TSetupDiGetDeviceInstanceIdW SetupDiGetDeviceInstanceIdW;
extern PACKAGE TSetupDiGetDeviceInstanceIdA SetupDiGetDeviceInstanceId;
extern PACKAGE TSetupDiDeleteDeviceInfo SetupDiDeleteDeviceInfo;
extern PACKAGE TSetupDiEnumDeviceInfo SetupDiEnumDeviceInfo;
extern PACKAGE TSetupDiDestroyDeviceInfoList SetupDiDestroyDeviceInfoList;
extern PACKAGE TSetupDiEnumDeviceInterfaces SetupDiEnumDeviceInterfaces;
extern PACKAGE TSetupDiEnumDeviceInterfaces SetupDiEnumInterfaceDevice;
extern PACKAGE TSetupDiCreateDeviceInterfaceA SetupDiCreateDeviceInterfaceA;
extern PACKAGE TSetupDiCreateDeviceInterfaceA SetupDiCreateInterfaceDeviceA;
extern PACKAGE TSetupDiCreateDeviceInterfaceW SetupDiCreateDeviceInterfaceW;
extern PACKAGE TSetupDiCreateDeviceInterfaceW SetupDiCreateInterfaceDeviceW;
extern PACKAGE TSetupDiCreateDeviceInterfaceA SetupDiCreateDeviceInterface;
extern PACKAGE TSetupDiOpenDeviceInterfaceA SetupDiOpenDeviceInterfaceA;
extern PACKAGE TSetupDiOpenDeviceInterfaceA SetupDiOpenInterfaceDeviceA;
extern PACKAGE TSetupDiOpenDeviceInterfaceW SetupDiOpenDeviceInterfaceW;
extern PACKAGE TSetupDiOpenDeviceInterfaceW SetupDiOpenInterfaceDeviceW;
extern PACKAGE TSetupDiOpenDeviceInterfaceA SetupDiOpenDeviceInterface;
extern PACKAGE TSetupDiGetDeviceInterfaceAlias SetupDiGetDeviceInterfaceAlias;
extern PACKAGE TSetupDiGetDeviceInterfaceAlias SetupDiGetInterfaceDeviceAlias;
extern PACKAGE TSetupDiDeleteDeviceInterfaceData SetupDiDeleteDeviceInterfaceData;
extern PACKAGE TSetupDiDeleteDeviceInterfaceData SetupDiDeleteInterfaceDeviceData;
extern PACKAGE TSetupDiRemoveDeviceInterface SetupDiRemoveDeviceInterface;
extern PACKAGE TSetupDiRemoveDeviceInterface SetupDiRemoveInterfaceDevice;
extern PACKAGE TSetupDiGetDeviceInterfaceDetailA SetupDiGetDeviceInterfaceDetailA;
extern PACKAGE TSetupDiGetDeviceInterfaceDetailA SetupDiGetInterfaceDeviceDetailA;
extern PACKAGE TSetupDiGetDeviceInterfaceDetailW SetupDiGetDeviceInterfaceDetailW;
extern PACKAGE TSetupDiGetDeviceInterfaceDetailW SetupDiGetInterfaceDeviceDetailW;
extern PACKAGE TSetupDiGetDeviceInterfaceDetailA SetupDiGetDeviceInterfaceDetail;
extern PACKAGE TSetupDiInstallDeviceInterfaces SetupDiInstallDeviceInterfaces;
extern PACKAGE TSetupDiInstallDeviceInterfaces SetupDiInstallInterfaceDevices;
extern PACKAGE TSetupDiRegisterDeviceInfo SetupDiRegisterDeviceInfo;
extern PACKAGE TSetupDiBuildDriverInfoList SetupDiBuildDriverInfoList;
extern PACKAGE TSetupDiCancelDriverInfoSearch SetupDiCancelDriverInfoSearch;
extern PACKAGE TSetupDiEnumDriverInfoA SetupDiEnumDriverInfoA;
extern PACKAGE TSetupDiEnumDriverInfoW SetupDiEnumDriverInfoW;
extern PACKAGE TSetupDiEnumDriverInfoA SetupDiEnumDriverInfo;
extern PACKAGE TSetupDiGetSelectedDriverA SetupDiGetSelectedDriverA;
extern PACKAGE TSetupDiGetSelectedDriverW SetupDiGetSelectedDriverW;
extern PACKAGE TSetupDiGetSelectedDriverA SetupDiGetSelectedDriver;
extern PACKAGE TSetupDiSetSelectedDriverA SetupDiSetSelectedDriverA;
extern PACKAGE TSetupDiSetSelectedDriverW SetupDiSetSelectedDriverW;
extern PACKAGE TSetupDiSetSelectedDriverA SetupDiSetSelectedDriver;
extern PACKAGE TSetupDiGetDriverInfoDetailA SetupDiGetDriverInfoDetailA;
extern PACKAGE TSetupDiGetDriverInfoDetailW SetupDiGetDriverInfoDetailW;
extern PACKAGE TSetupDiGetDriverInfoDetailA SetupDiGetDriverInfoDetail;
extern PACKAGE TSetupDiDestroyDriverInfoList SetupDiDestroyDriverInfoList;
extern PACKAGE TSetupDiGetClassDevsA SetupDiGetClassDevsA;
extern PACKAGE TSetupDiGetClassDevsW SetupDiGetClassDevsW;
extern PACKAGE TSetupDiGetClassDevsA SetupDiGetClassDevs;
extern PACKAGE TSetupDiGetClassDevsExA SetupDiGetClassDevsExA;
extern PACKAGE TSetupDiGetClassDevsExW SetupDiGetClassDevsExW;
extern PACKAGE TSetupDiGetClassDevsExA SetupDiGetClassDevsEx;
extern PACKAGE TSetupDiGetINFClassA SetupDiGetINFClassA;
extern PACKAGE TSetupDiGetINFClassW SetupDiGetINFClassW;
extern PACKAGE TSetupDiGetINFClassA SetupDiGetINFClass;
extern PACKAGE TSetupDiBuildClassInfoList SetupDiBuildClassInfoList;
extern PACKAGE TSetupDiBuildClassInfoListExA SetupDiBuildClassInfoListExA;
extern PACKAGE TSetupDiBuildClassInfoListExW SetupDiBuildClassInfoListExW;
extern PACKAGE TSetupDiBuildClassInfoListExA SetupDiBuildClassInfoListEx;
extern PACKAGE TSetupDiGetClassDescriptionA SetupDiGetClassDescriptionA;
extern PACKAGE TSetupDiGetClassDescriptionW SetupDiGetClassDescriptionW;
extern PACKAGE TSetupDiGetClassDescriptionA SetupDiGetClassDescription;
extern PACKAGE TSetupDiGetClassDescriptionExA SetupDiGetClassDescriptionExA;
extern PACKAGE TSetupDiGetClassDescriptionExW SetupDiGetClassDescriptionExW;
extern PACKAGE TSetupDiGetClassDescriptionExA SetupDiGetClassDescriptionEx;
extern PACKAGE TSetupDiCallClassInstaller SetupDiCallClassInstaller;
extern PACKAGE TSetupDiSelectDevice SetupDiSelectDevice;
extern PACKAGE TSetupDiSelectBestCompatDrv SetupDiSelectBestCompatDrv;
extern PACKAGE TSetupDiInstallDevice SetupDiInstallDevice;
extern PACKAGE TSetupDiInstallDriverFiles SetupDiInstallDriverFiles;
extern PACKAGE TSetupDiRegisterCoDeviceInstallers SetupDiRegisterCoDeviceInstallers;
extern PACKAGE TSetupDiRemoveDevice SetupDiRemoveDevice;
extern PACKAGE TSetupDiUnremoveDevice SetupDiUnremoveDevice;
extern PACKAGE TSetupDiMoveDuplicateDevice SetupDiMoveDuplicateDevice;
extern PACKAGE TSetupDiChangeState SetupDiChangeState;
extern PACKAGE TSetupDiInstallClassA SetupDiInstallClassA;
extern PACKAGE TSetupDiInstallClassW SetupDiInstallClassW;
extern PACKAGE TSetupDiInstallClassA SetupDiInstallClass;
extern PACKAGE TSetupDiInstallClassExA SetupDiInstallClassExA;
extern PACKAGE TSetupDiInstallClassExW SetupDiInstallClassExW;
extern PACKAGE TSetupDiInstallClassExA SetupDiInstallClassEx;
extern PACKAGE TSetupDiOpenClassRegKey SetupDiOpenClassRegKey;
extern PACKAGE TSetupDiOpenClassRegKeyExA SetupDiOpenClassRegKeyExA;
extern PACKAGE TSetupDiOpenClassRegKeyExW SetupDiOpenClassRegKeyExW;
extern PACKAGE TSetupDiOpenClassRegKeyExA SetupDiOpenClassRegKeyEx;
extern PACKAGE TSetupDiCreateDeviceInterfaceRegKeyA SetupDiCreateDeviceInterfaceRegKeyA;
extern PACKAGE TSetupDiCreateDeviceInterfaceRegKeyA SetupDiCreateInterfaceDeviceRegKeyA;
extern PACKAGE TSetupDiCreateDeviceInterfaceRegKeyW SetupDiCreateDeviceInterfaceRegKeyW;
extern PACKAGE TSetupDiCreateDeviceInterfaceRegKeyW SetupDiCreateInterfaceDeviceRegKeyW;
extern PACKAGE TSetupDiCreateDeviceInterfaceRegKeyA SetupDiCreateDeviceInterfaceRegKey;
extern PACKAGE TSetupDiOpenDeviceInterfaceRegKey SetupDiOpenDeviceInterfaceRegKey;
extern PACKAGE TSetupDiOpenDeviceInterfaceRegKey SetupDiOpenInterfaceDeviceRegKey;
extern PACKAGE TSetupDiDeleteDeviceInterfaceRegKey SetupDiDeleteDeviceInterfaceRegKey;
extern PACKAGE TSetupDiDeleteDeviceInterfaceRegKey SetupDiDeleteInterfaceDeviceRegKey;
extern PACKAGE TSetupDiCreateDevRegKeyA SetupDiCreateDevRegKeyA;
extern PACKAGE TSetupDiCreateDevRegKeyW SetupDiCreateDevRegKeyW;
extern PACKAGE TSetupDiCreateDevRegKeyA SetupDiCreateDevRegKey;
extern PACKAGE TSetupDiOpenDevRegKey SetupDiOpenDevRegKey;
extern PACKAGE TSetupDiDeleteDevRegKey SetupDiDeleteDevRegKey;
extern PACKAGE TSetupDiGetHwProfileList SetupDiGetHwProfileList;
extern PACKAGE TSetupDiGetHwProfileListExA SetupDiGetHwProfileListExA;
extern PACKAGE TSetupDiGetHwProfileListExW SetupDiGetHwProfileListExW;
extern PACKAGE TSetupDiGetHwProfileListExA SetupDiGetHwProfileListEx;
extern PACKAGE TSetupDiGetDeviceRegistryPropertyA SetupDiGetDeviceRegistryPropertyA;
extern PACKAGE TSetupDiGetDeviceRegistryPropertyW SetupDiGetDeviceRegistryPropertyW;
extern PACKAGE TSetupDiGetDeviceRegistryPropertyA SetupDiGetDeviceRegistryProperty;
extern PACKAGE TSetupDiSetDeviceRegistryPropertyA SetupDiSetDeviceRegistryPropertyA;
extern PACKAGE TSetupDiSetDeviceRegistryPropertyW SetupDiSetDeviceRegistryPropertyW;
extern PACKAGE TSetupDiSetDeviceRegistryPropertyA SetupDiSetDeviceRegistryProperty;
extern PACKAGE TSetupDiGetDeviceInstallParamsA SetupDiGetDeviceInstallParamsA;
extern PACKAGE TSetupDiGetDeviceInstallParamsW SetupDiGetDeviceInstallParamsW;
extern PACKAGE TSetupDiGetDeviceInstallParamsA SetupDiGetDeviceInstallParams;
extern PACKAGE TSetupDiGetClassInstallParamsA SetupDiGetClassInstallParamsA;
extern PACKAGE TSetupDiGetClassInstallParamsW SetupDiGetClassInstallParamsW;
extern PACKAGE TSetupDiGetClassInstallParamsA SetupDiGetClassInstallParams;
extern PACKAGE TSetupDiSetDeviceInstallParamsA SetupDiSetDeviceInstallParamsA;
extern PACKAGE TSetupDiSetDeviceInstallParamsW SetupDiSetDeviceInstallParamsW;
extern PACKAGE TSetupDiSetDeviceInstallParamsA SetupDiSetDeviceInstallParams;
extern PACKAGE TSetupDiSetClassInstallParamsA SetupDiSetClassInstallParamsA;
extern PACKAGE TSetupDiSetClassInstallParamsW SetupDiSetClassInstallParamsW;
extern PACKAGE TSetupDiSetClassInstallParamsA SetupDiSetClassInstallParams;
extern PACKAGE TSetupDiGetDriverInstallParamsA SetupDiGetDriverInstallParamsA;
extern PACKAGE TSetupDiGetDriverInstallParamsW SetupDiGetDriverInstallParamsW;
extern PACKAGE TSetupDiGetDriverInstallParamsA SetupDiGetDriverInstallParams;
extern PACKAGE TSetupDiSetDriverInstallParamsA SetupDiSetDriverInstallParamsA;
extern PACKAGE TSetupDiSetDriverInstallParamsW SetupDiSetDriverInstallParamsW;
extern PACKAGE TSetupDiSetDriverInstallParamsA SetupDiSetDriverInstallParams;
extern PACKAGE TSetupDiLoadClassIcon SetupDiLoadClassIcon;
extern PACKAGE TSetupDiDrawMiniIcon SetupDiDrawMiniIcon;
extern PACKAGE TSetupDiGetClassBitmapIndex SetupDiGetClassBitmapIndex;
extern PACKAGE TSetupDiGetClassImageList SetupDiGetClassImageList;
extern PACKAGE TSetupDiGetClassImageListExA SetupDiGetClassImageListExA;
extern PACKAGE TSetupDiGetClassImageListExW SetupDiGetClassImageListExW;
extern PACKAGE TSetupDiGetClassImageListExA SetupDiGetClassImageListEx;
extern PACKAGE TSetupDiGetClassImageIndex SetupDiGetClassImageIndex;
extern PACKAGE TSetupDiDestroyClassImageList SetupDiDestroyClassImageList;
extern PACKAGE TSetupDiGetClassDevPropertySheetsA SetupDiGetClassDevPropertySheetsA;
extern PACKAGE TSetupDiGetClassDevPropertySheetsW SetupDiGetClassDevPropertySheetsW;
extern PACKAGE TSetupDiGetClassDevPropertySheetsA SetupDiGetClassDevPropertySheets;
extern PACKAGE TSetupDiAskForOEMDisk SetupDiAskForOEMDisk;
extern PACKAGE TSetupDiSelectOEMDrv SetupDiSelectOEMDrv;
extern PACKAGE TSetupDiClassNameFromGuidA SetupDiClassNameFromGuidA;
extern PACKAGE TSetupDiClassNameFromGuidW SetupDiClassNameFromGuidW;
extern PACKAGE TSetupDiClassNameFromGuidA SetupDiClassNameFromGuid;
extern PACKAGE TSetupDiClassNameFromGuidExA SetupDiClassNameFromGuidExA;
extern PACKAGE TSetupDiClassNameFromGuidExW SetupDiClassNameFromGuidExW;
extern PACKAGE TSetupDiClassNameFromGuidExA SetupDiClassNameFromGuidEx;
extern PACKAGE TSetupDiClassGuidsFromNameA SetupDiClassGuidsFromNameA;
extern PACKAGE TSetupDiClassGuidsFromNameW SetupDiClassGuidsFromNameW;
extern PACKAGE TSetupDiClassGuidsFromNameA SetupDiClassGuidsFromName;
extern PACKAGE TSetupDiClassGuidsFromNameExA SetupDiClassGuidsFromNameExA;
extern PACKAGE TSetupDiClassGuidsFromNameExW SetupDiClassGuidsFromNameExW;
extern PACKAGE TSetupDiClassGuidsFromNameExA SetupDiClassGuidsFromNameEx;
extern PACKAGE TSetupDiGetHwProfileFriendlyNameA SetupDiGetHwProfileFriendlyNameA;
extern PACKAGE TSetupDiGetHwProfileFriendlyNameW SetupDiGetHwProfileFriendlyNameW;
extern PACKAGE TSetupDiGetHwProfileFriendlyNameA SetupDiGetHwProfileFriendlyName;
extern PACKAGE TSetupDiGetHwProfileFriendlyNameExA SetupDiGetHwProfileFriendlyNameExA;
extern PACKAGE TSetupDiGetHwProfileFriendlyNameExW SetupDiGetHwProfileFriendlyNameExW;
extern PACKAGE TSetupDiGetHwProfileFriendlyNameExA SetupDiGetHwProfileFriendlyNameEx;
extern PACKAGE TSetupDiGetWizardPage SetupDiGetWizardPage;
extern PACKAGE TSetupDiGetSelectedDevice SetupDiGetSelectedDevice;
extern PACKAGE TSetupDiSetSelectedDevice SetupDiSetSelectedDevice;
extern PACKAGE TSetupDiGetActualSectionToInstallA SetupDiGetActualSectionToInstallA;
extern PACKAGE TSetupDiGetActualSectionToInstallW SetupDiGetActualSectionToInstallW;
extern PACKAGE TSetupDiGetActualSectionToInstall SetupDiGetActualSectionToInstall;
extern PACKAGE bool __fastcall IsSetupApiLoaded(void);
extern PACKAGE bool __fastcall LoadSetupApi(void);
extern PACKAGE void __fastcall UnloadSetupApi(void);

}	/* namespace Setupapi */
using namespace Setupapi;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SetupApi
