// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ModuleLoader.pas' rev: 6.00

#ifndef ModuleLoaderHPP
#define ModuleLoaderHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Moduleloader
{
//-- type declarations -------------------------------------------------------
typedef unsigned TModuleHandle;

//-- var, const, procedure ---------------------------------------------------
static const unsigned INVALID_MODULEHANDLE_VALUE = 0x0;
extern PACKAGE bool __fastcall LoadModule(unsigned &Module, AnsiString FileName);
extern PACKAGE bool __fastcall LoadModuleEx(unsigned &Module, AnsiString FileName, unsigned Flags);
extern PACKAGE void __fastcall UnloadModule(unsigned &Module);
extern PACKAGE void * __fastcall GetModuleSymbol(unsigned Module, AnsiString SymbolName);
extern PACKAGE void * __fastcall GetModuleSymbolEx(unsigned Module, AnsiString SymbolName, bool &Accu);
extern PACKAGE bool __fastcall ReadModuleData(unsigned Module, AnsiString SymbolName, void *Buffer, unsigned Size);
extern PACKAGE bool __fastcall WriteModuleData(unsigned Module, AnsiString SymbolName, void *Buffer, unsigned Size);

}	/* namespace Moduleloader */
using namespace Moduleloader;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ModuleLoader
