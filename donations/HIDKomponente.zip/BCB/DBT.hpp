// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'DBT.pas' rev: 6.00

#ifndef DBTHPP
#define DBTHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

#include <dbt.h>


namespace Dbt
{
//-- type declarations -------------------------------------------------------
typedef DEV_BROADCAST_HDR *PDevBroadcastHdr;

typedef DEV_BROADCAST_HDR  TDevBroadcastHdr;

typedef VolLockBroadcast *PVolLockBroadcast;

typedef VolLockBroadcast  TVolLockBroadcast;

struct DEV_BROADCAST_HEADER;
typedef DEV_BROADCAST_HEADER *PDevBroadcastHeader;

#pragma pack(push, 1)
struct DEV_BROADCAST_HEADER
{
	unsigned dbcd_size;
	unsigned dbcd_devicetype;
	unsigned dbcd_reserved;
} ;
#pragma pack(pop)

typedef DEV_BROADCAST_HEADER  TDevBroadcastHeader;

typedef DEV_BROADCAST_OEM *PDevBroadcastOem;

typedef DEV_BROADCAST_OEM  TDevBroadcastOem;

typedef DEV_BROADCAST_DEVNODE *PDevBroadcastDevNode;

typedef DEV_BROADCAST_DEVNODE  TDevBroadcastDevNode;

typedef DEV_BROADCAST_VOLUME *PDevBroadcastVolume;

typedef DEV_BROADCAST_VOLUME  TDevBroadcastVolume;

typedef DEV_BROADCAST_PORT_A *PDevBroadCastPortA;

typedef DEV_BROADCAST_PORT_A  TDevBroadCastPortA;

typedef DEV_BROADCAST_PORT_W *PDevBroadCastPortW;

typedef DEV_BROADCAST_PORT_W  TDevBroadCastPortW;

typedef DEV_BROADCAST_PORT_A *PDevBroadCastPort;

typedef DEV_BROADCAST_NET *PDevBroadcastNet;

typedef DEV_BROADCAST_NET  TDevBroadcastNet;

typedef DEV_BROADCAST_DEVICEINTERFACE_A *PDevBroadcastDeviceInterfaceA;

typedef DEV_BROADCAST_DEVICEINTERFACE_A  TDevBroadcastDeviceInterfaceA;

typedef DEV_BROADCAST_DEVICEINTERFACE_W *PDevBroadcastDeviceInterfaceW;

typedef DEV_BROADCAST_DEVICEINTERFACE_W  TDevBroadcastDeviceInterfaceW;

typedef DEV_BROADCAST_DEVICEINTERFACE_A *PDevBroadcastDeviceInterface;

typedef DEV_BROADCAST_HANDLE *PDevBroadcastHandle;

typedef DEV_BROADCAST_HANDLE  TDevBroadcastHandle;

struct DEV_BROADCAST_USERDEFINED;
typedef DEV_BROADCAST_USERDEFINED *PDevBroadcastUserdefined;

#pragma pack(push, 1)
struct DEV_BROADCAST_USERDEFINED
{
	DEV_BROADCAST_HDR dbud_dbh;
	char dbud_szName[1];
} ;
#pragma pack(pop)

typedef DEV_BROADCAST_USERDEFINED  TDevBroadcastUserdefined;

#pragma pack(push, 4)
struct TWMDeviceChange
{
	unsigned Msg;
	unsigned Event;
	void *dwData;
	int Result;
} ;
#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dbt */
using namespace Dbt;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DBT
